import { useState } from 'react';
import { HelpCircle, CheckCircle2 } from 'lucide-react';
import { Modal } from '@/components/ui/Modal';
import { getSuggestedEvidences } from '@/constants/suggestedEvidences';

interface EvidenceGuideButtonProps {
  criterion: { id: string; label: string };
  /** الأمثلة مخصصة لنموذج المعلم؛ تُخفى لبقية النماذج */
  formType?: string;
}

export function EvidenceGuideButton({ criterion, formType }: EvidenceGuideButtonProps) {
  const [open, setOpen] = useState(false);
  if (formType && formType !== 'teacher') return null;
  const guide = getSuggestedEvidences(criterion);
  if (!guide) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="inline-flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-secondary-100 text-secondary-600 transition-colors hover:bg-secondary-200"
        title="أمثلة للشواهد المقترحة لهذا المعيار"
        aria-label="أمثلة للشواهد المقترحة لهذا المعيار"
      >
        <HelpCircle size={16} />
      </button>
      <Modal open={open} onClose={() => setOpen(false)} title="أمثلة للشواهد المقترحة لهذا المعيار" size="sm">
        <div className="space-y-3">
          <p className="rounded-lg bg-secondary-50 px-3 py-2 text-sm font-bold text-secondary-800">{guide.criterionName}</p>
          <ul className="space-y-2">
            {guide.suggestedEvidences.map((text) => (
              <li key={text} className="flex items-start gap-2 text-sm leading-relaxed text-neutral-700">
                <CheckCircle2 size={16} className="mt-0.5 flex-shrink-0 text-success-600" />
                <span>{text}</span>
              </li>
            ))}
          </ul>
          <button type="button" onClick={() => setOpen(false)} className="btn-outline w-full">إغلاق</button>
        </div>
      </Modal>
    </>
  );
}
