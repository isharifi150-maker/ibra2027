import { useEffect, useState } from 'react';
import { Download, Smartphone, X } from 'lucide-react';

interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

// Captured at import time because the browser may fire the event before React mounts.
let deferredPrompt: InstallPromptEvent | null = null;
const listeners = new Set<() => void>();
if (typeof window !== 'undefined') {
  window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e as InstallPromptEvent;
    listeners.forEach((l) => l());
  });
  window.addEventListener('appinstalled', () => {
    deferredPrompt = null;
    listeners.forEach((l) => l());
  });
}

const DISMISS_KEY = 'install-card-dismissed';

const isStandalone = (): boolean =>
  window.matchMedia('(display-mode: standalone)').matches ||
  (navigator as unknown as { standalone?: boolean }).standalone === true;

const isIos = (): boolean =>
  /iphone|ipad|ipod/i.test(navigator.userAgent) ||
  (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);

export function InstallAppCard() {
  const [, setTick] = useState(0);
  const [showHelp, setShowHelp] = useState(false);
  const [dismissed, setDismissed] = useState(() => {
    try { return localStorage.getItem(DISMISS_KEY) === '1'; } catch { return false; }
  });

  useEffect(() => {
    const update = () => setTick((t) => t + 1);
    listeners.add(update);
    return () => { listeners.delete(update); };
  }, []);

  if (dismissed || isStandalone()) return null;

  const dismiss = () => {
    setDismissed(true);
    try { localStorage.setItem(DISMISS_KEY, '1'); } catch { /* ignore */ }
  };

  const handleInstall = async () => {
    if (deferredPrompt) {
      const promptEvent = deferredPrompt;
      deferredPrompt = null;
      await promptEvent.prompt();
      await promptEvent.userChoice.catch(() => undefined);
      setTick((t) => t + 1);
      return;
    }
    setShowHelp(true); // no native prompt available (iPhone, or browser does not offer it)
  };

  return (
    <div className="rounded-xl border border-primary-200 bg-primary-50 px-4 py-3 text-sm text-primary-800">
      <div className="flex items-start gap-3">
        <Smartphone size={20} className="mt-0.5 flex-shrink-0" />
        <div className="min-w-0 flex-1 space-y-2">
          <p className="font-bold">ثبّت النظام كتطبيق على جوالك</p>
          <p className="text-xs leading-relaxed">يفتح بضغطة واحدة من الشاشة الرئيسية، وبدون شريط المتصفح.</p>
          <button type="button" onClick={handleInstall} className="btn-primary text-xs">
            <Download size={14} /> تثبيت التطبيق
          </button>
          {showHelp && (
            <div className="rounded-lg bg-white/70 px-3 py-2 text-xs leading-relaxed text-neutral-700">
              {isIos() ? (
                <>في iPhone (متصفح Safari): اضغط زر المشاركة <b>⎋</b> أسفل الشاشة، ثم اختر <b>«إضافة إلى الشاشة الرئيسية»</b>، ثم <b>«إضافة»</b>.</>
              ) : (
                <>اضغط قائمة المتصفح <b>⋮</b> في الأعلى، ثم اختر <b>«تثبيت التطبيق»</b> أو <b>«إضافة إلى الشاشة الرئيسية»</b>.</>
              )}
            </div>
          )}
        </div>
        <button type="button" onClick={dismiss} aria-label="إخفاء" className="flex-shrink-0 text-primary-600"><X size={16} /></button>
      </div>
    </div>
  );
}
