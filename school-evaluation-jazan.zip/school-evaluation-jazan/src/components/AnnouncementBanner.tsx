import { useEffect, useState } from 'react';
import { Megaphone, CalendarClock } from 'lucide-react';
import { getAnnouncement, type Announcement } from '@/db';
import { formatDateShort } from '@/utils';

function daysLeft(deadline: string): number {
  const end = new Date(`${deadline}T23:59:59`).getTime();
  return Math.ceil((end - Date.now()) / (24 * 60 * 60 * 1000));
}

export function AnnouncementBanner() {
  const [announcement, setAnnouncement] = useState<Announcement | undefined>();

  useEffect(() => {
    let active = true;
    getAnnouncement().then((a) => { if (active) setAnnouncement(a); }).catch(() => undefined);
    return () => { active = false; };
  }, []);

  if (!announcement) return null;

  const left = announcement.deadline ? daysLeft(announcement.deadline) : null;
  const urgent = left !== null && left <= 3;

  return (
    <div className={`rounded-xl border px-4 py-3 text-sm ${urgent ? 'border-warning-300 bg-warning-50 text-warning-800' : 'border-primary-200 bg-primary-50 text-primary-800'}`}>
      <div className="flex items-start gap-2">
        <Megaphone size={18} className="mt-0.5 flex-shrink-0" />
        <div className="space-y-1">
          {announcement.text && <p className="font-bold leading-relaxed">{announcement.text}</p>}
          {announcement.deadline && left !== null && (
            <p className="flex items-center gap-1 text-xs">
              <CalendarClock size={14} />
              آخر موعد لرفع الشواهد: {formatDateShort(new Date(`${announcement.deadline}T12:00:00`).getTime())}
              {left > 0 ? ` (متبقي ${left} يوم)` : left === 0 ? ' (ينتهي اليوم)' : ' (انتهى الموعد)'}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
