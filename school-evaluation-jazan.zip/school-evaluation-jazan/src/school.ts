// Shared constants and helpers for official printouts and exports.
export const PRINCIPAL_NAME = 'فيصل علي قحل';
export const DEPARTMENT_NAME = 'الإدارة العامة للتعليم بمنطقة جازان';

export type EvalPeriod = 'midyear' | 'final';
export const PERIOD_LABELS: Record<EvalPeriod, string> = {
  midyear: 'التقييم النصف سنوي',
  final: 'التقييم النهائي',
};

export const escapeHtml = (value: string): string =>
  value.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&#39;');

export function todayStamp(): string {
  return new Date().toISOString().slice(0, 10);
}
