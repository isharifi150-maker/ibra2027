// Dependency-free charts rendered as HTML/SVG strings (same output in the app and in print windows).
import { escapeHtml } from '@/school';

const KEEP_COLORS = '-webkit-print-color-adjust:exact;print-color-adjust:exact';

export function ratingColor(percent: number): string {
  if (percent < 60) return '#dc2626';
  if (percent < 75) return '#f59e0b';
  if (percent < 90) return '#2563eb';
  return '#16a34a';
}

const clampPercent = (v: number) => Math.max(0, Math.min(100, Number.isFinite(v) ? v : 0));

export interface BarItem { label: string; percent: number; text?: string }

/** Horizontal bars, one row per item, color by performance level. */
export function hBarsHtml(items: BarItem[]): string {
  if (!items.length) return '';
  const rows = items.map((i) => `
    <div style="break-inside:avoid;page-break-inside:avoid">
      <div style="display:flex;justify-content:space-between;gap:8px;font-size:12px;margin-bottom:3px">
        <span>${escapeHtml(i.label)}</span><b style="white-space:nowrap">${escapeHtml(i.text ?? `${i.percent.toFixed(1)}%`)}</b>
      </div>
      <div style="height:10px;background:#e5e7eb;border-radius:6px;overflow:hidden;${KEEP_COLORS}">
        <div style="height:100%;width:${clampPercent(i.percent)}%;background:${ratingColor(i.percent)};border-radius:6px;${KEEP_COLORS}"></div>
      </div>
    </div>`).join('');
  return `<div style="display:flex;flex-direction:column;gap:9px">${rows}</div>`;
}

export interface DonutSegment { label: string; value: number; color: string }

/** Donut chart with a legend. */
export function donutHtml(segments: DonutSegment[], centerText: string, size = 150): string {
  const total = segments.reduce((s, x) => s + x.value, 0);
  let offset = 25; // start at 12 o'clock
  const arcs = total > 0
    ? segments.filter((s) => s.value > 0).map((s) => {
        const pct = (s.value / total) * 100;
        const arc = `<circle cx="21" cy="21" r="15.9155" fill="none" stroke="${s.color}" stroke-width="6" stroke-dasharray="${pct} ${100 - pct}" stroke-dashoffset="${offset}"/>`;
        offset -= pct;
        return arc;
      }).join('')
    : '';
  const legend = segments.map((s) => `
    <div style="display:flex;align-items:center;gap:6px;font-size:12px">
      <span style="width:10px;height:10px;border-radius:2px;background:${s.color};display:inline-block;${KEEP_COLORS}"></span>
      <span>${escapeHtml(s.label)}</span><b>${s.value}</b>
    </div>`).join('');
  return `<div style="display:flex;flex-wrap:wrap;align-items:center;gap:16px;break-inside:avoid;page-break-inside:avoid">
    <svg viewBox="0 0 42 42" width="${size}" height="${size}" style="${KEEP_COLORS}">
      <circle cx="21" cy="21" r="15.9155" fill="none" stroke="#e5e7eb" stroke-width="6"/>
      ${arcs}
      <text x="21" y="22.5" text-anchor="middle" font-size="5.5" font-weight="bold" fill="#111">${escapeHtml(centerText)}</text>
    </svg>
    <div style="display:flex;flex-direction:column;gap:5px">${legend}</div>
  </div>`;
}

export interface PairRow { label: string; a: number | null; b: number | null }

/** Two thin bars per row (e.g. mid-year vs final). Values are percentages. */
export function pairedBarsHtml(rows: PairRow[], names: [string, string], colors: [string, string] = ['#94a3b8', '#2563eb']): string {
  if (!rows.length) return '';
  const bar = (value: number | null, color: string) => `
    <div style="display:flex;align-items:center;gap:6px">
      <div style="flex:1;height:8px;background:#e5e7eb;border-radius:5px;overflow:hidden;${KEEP_COLORS}">
        <div style="height:100%;width:${value === null ? 0 : clampPercent(value)}%;background:${color};${KEEP_COLORS}"></div>
      </div>
      <span style="width:42px;font-size:11px;text-align:left">${value === null ? '—' : `${value.toFixed(1)}%`}</span>
    </div>`;
  const legend = `<div style="display:flex;gap:14px;font-size:12px;margin-bottom:8px">
    ${[0, 1].map((i) => `<span style="display:flex;align-items:center;gap:5px"><span style="width:10px;height:10px;border-radius:2px;background:${colors[i]};display:inline-block;${KEEP_COLORS}"></span>${escapeHtml(names[i])}</span>`).join('')}
  </div>`;
  const body = rows.map((r) => `
    <div style="break-inside:avoid;page-break-inside:avoid;margin-bottom:9px">
      <div style="font-size:12px;margin-bottom:3px">${escapeHtml(r.label)}</div>
      ${bar(r.a, colors[0])}${bar(r.b, colors[1])}
    </div>`).join('');
  return `<div>${legend}${body}</div>`;
}
