import { EVALUATION_FORMS, getRatingLabel } from '@/forms';
import { pairedBarsHtml, ratingColor } from '@/charts';
import { LOGO_DATA_URI, SIGNATURE_DATA_URI, STAMP_DATA_URI } from '@/assets/schoolAssets';
import { DEPARTMENT_NAME, SCHOOL_NAME, PRINCIPAL_NAME, escapeHtml } from '@/school';
import type { User, Evaluation } from '@/types';

const ratingOf = (ev: Evaluation | undefined, criterionId: string): number | null => {
  const sc = ev?.scores?.find((x) => x.criterionId === criterionId);
  return sc && sc.rating ? sc.rating : null;
};

export function buildIndividualReportHtml(emp: User, evals: Evaluation[]): string {
  const form = EVALUATION_FORMS[emp.formType || 'teacher'];
  const mid = evals.find((e) => e.period === 'midyear');
  const fin = evals.find((e) => e.period === 'final');
  const maxTotal = form.criteria.reduce((s, c) => s + c.weight, 0);

  const percentOf = (ev?: Evaluation): number | null => {
    if (!ev?.scores?.length) return null;
    const total = form.criteria.reduce((s, c) => {
      const r = ratingOf(ev, c.id);
      return s + (r ? (r / 5) * c.weight : 0);
    }, 0);
    return maxTotal ? (total / maxTotal) * 100 : 0;
  };
  const midPct = percentOf(mid);
  const finPct = percentOf(fin);
  const labelOf = (p: number | null) => (p === null ? '—' : getRatingLabel((p / 100) * 5));
  const delta = midPct !== null && finPct !== null ? finPct - midPct : null;

  // Latest available rating per criterion (final first, otherwise mid-year)
  const latest = form.criteria.map((c) => ({ c, r: ratingOf(fin, c.id) ?? ratingOf(mid, c.id) }));
  const rated = latest.filter((x): x is { c: typeof x.c; r: number } => x.r !== null);
  const strengths = [...rated].sort((a, b) => b.r - a.r).filter((x) => x.r >= 4).slice(0, 3);
  const development = [...rated].sort((a, b) => a.r - b.r).filter((x) => x.r <= 3).slice(0, 3);

  const rows = form.criteria.map((c, i) => {
    const a = ratingOf(mid, c.id);
    const b = ratingOf(fin, c.id);
    const d = a !== null && b !== null ? b - a : null;
    const dText = d === null ? '—' : d > 0 ? `▲ +${d}` : d < 0 ? `▼ ${d}` : '=';
    const dColor = d === null || d === 0 ? '#555' : d > 0 ? '#16a34a' : '#dc2626';
    return `<tr><td class="c">${i + 1}</td><td>${escapeHtml(c.label)}</td><td class="c">${c.weight}</td><td class="c">${a ?? '—'}</td><td class="c">${b ?? '—'}</td><td class="c" style="color:${dColor};font-weight:bold">${dText}</td></tr>`;
  }).join('');

  const chartRows = form.criteria.map((c) => {
    const a = ratingOf(mid, c.id);
    const b = ratingOf(fin, c.id);
    return { label: c.label, a: a === null ? null : (a / 5) * 100, b: b === null ? null : (b / 5) * 100 };
  });

  const list = (items: { c: { label: string }; r: number }[], empty: string) =>
    items.length ? `<ul style="margin:4px 0 0;padding-right:18px">${items.map((x) => `<li>${escapeHtml(x.c.label)} (${x.r} من 5)</li>`).join('')}</ul>` : `<p style="margin:4px 0 0;color:#666">${empty}</p>`;

  const kpi = (title: string, value: string, color = '#111') =>
    `<div><span style="font-size:11px;color:#555">${title}</span><b style="color:${color}">${value}</b></div>`;

  const approved = fin?.status === 'approved';

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8" />
<title>تقرير الأداء الفردي - ${escapeHtml(emp.fullName)}</title>
<style>
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, 'Noto Naskh Arabic', Arial, sans-serif; color: #111; font-size: 12px; margin: 0; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 12px; }
  .header div { line-height: 1.8; font-weight: bold; }
  .logo { height: 62px; width: auto; display: block; margin: 0 auto; }
  h1 { text-align: center; font-size: 17px; margin: 8px 0 12px; }
  h2 { font-size: 14px; margin: 14px 0 6px; }
  .info { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  .info td { border: 1px solid #444; padding: 6px 8px; }
  .info td.l { background: #eee; font-weight: bold; width: 18%; }
  .kpi { display: flex; gap: 8px; margin: 10px 0; }
  .kpi div { flex: 1; border: 1px solid #444; padding: 8px; text-align: center; }
  .kpi b { display: block; font-size: 16px; margin-top: 2px; }
  table.crit { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  table.crit th, table.crit td { border: 1px solid #444; padding: 4px 6px; }
  table.crit th { background: #ddd; }
  td.c, th.c { text-align: center; }
  .two { display: flex; gap: 10px; }
  .two > div { flex: 1; border: 1px solid #444; padding: 8px; }
  .lines p { border-bottom: 1px dotted #555; height: 22px; margin: 0; }
  .sign { display: flex; gap: 20px; margin-top: 16px; }
  .sign .box { flex: 1; border: 1px solid #444; padding: 10px; min-height: 100px; }
  .sign .box b { display: block; margin-bottom: 6px; }
  .seal { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
  .seal .sig { height: 55px; width: auto; } .seal .stamp { height: 85px; width: auto; }
  tr, .two > div, .kpi div { page-break-inside: avoid; }
</style></head><body>
  <div class="header">
    <div>المملكة العربية السعودية<br/>وزارة التعليم<br/>${DEPARTMENT_NAME}<br/>${SCHOOL_NAME}</div>
    <div><img class="logo" src="${LOGO_DATA_URI}" alt="" /></div>
    <div>التاريخ: ......../......../........ هـ</div>
  </div>
  <h1>تقرير الأداء الوظيفي الفردي</h1>
  <table class="info">
    <tr><td class="l">الاسم</td><td>${escapeHtml(emp.fullName)}</td><td class="l">السجل المدني</td><td>${escapeHtml(emp.civilId)}</td></tr>
    <tr><td class="l">المسمى الوظيفي</td><td>${escapeHtml(emp.jobTitle || form.shortName)}</td><td class="l">نموذج التقييم</td><td>${escapeHtml(form.name)}</td></tr>
  </table>
  <div class="kpi">
    ${kpi('النصف سنوي', midPct === null ? '—' : `${midPct.toFixed(1)}% • ${labelOf(midPct)}`, midPct === null ? '#111' : ratingColor(midPct))}
    ${kpi('النهائي', finPct === null ? '—' : `${finPct.toFixed(1)}% • ${labelOf(finPct)}`, finPct === null ? '#111' : ratingColor(finPct))}
    ${kpi('التغيّر', delta === null ? '—' : `${delta > 0 ? '▲ +' : delta < 0 ? '▼ ' : ''}${delta.toFixed(1)}%`, delta === null || delta === 0 ? '#111' : delta > 0 ? '#16a34a' : '#dc2626')}
  </div>
  <h2>مقارنة الأداء حسب البند</h2>
  ${pairedBarsHtml(chartRows, ['النصف سنوي', 'النهائي'])}
  <h2>تفاصيل الدرجات</h2>
  <table class="crit">
    <thead><tr><th class="c" style="width:6%">م</th><th>البند</th><th class="c" style="width:9%">الوزن</th><th class="c" style="width:12%">نصف سنوي</th><th class="c" style="width:12%">نهائي</th><th class="c" style="width:12%">التغيّر</th></tr></thead>
    <tbody>${rows}</tbody>
  </table>
  <div class="two">
    <div><b style="color:#16a34a">نقاط القوة</b>${list(strengths, 'لا توجد بنود بتقدير 4 أو أعلى بعد')}</div>
    <div><b style="color:#dc2626">فرص التطوير</b>${list(development, 'لا توجد بنود بتقدير 3 أو أقل')}</div>
  </div>
  <h2>توصيات وخطة التطوير (مدير المدرسة)</h2>
  <div class="lines"><p></p><p></p><p></p></div>
  <div class="sign">
    <div class="box"><b>المعلم / الموظف</b>الاسم: ${escapeHtml(emp.fullName)}<div style="margin-top:20px">التوقيع: ..............................</div></div>
    <div class="box"><b>مدير المدرسة</b>الاسم: ${PRINCIPAL_NAME}${approved
      ? `<div class="seal"><img class="sig" src="${SIGNATURE_DATA_URI}" alt="" /><img class="stamp" src="${STAMP_DATA_URI}" alt="" /></div>`
      : `<div style="margin-top:20px">التوقيع: ..............................</div><div style="margin-top:14px">الاعتماد / الختم: ..............................</div>`}</div>
  </div>
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 300); };</script>
</body></html>`;
}
