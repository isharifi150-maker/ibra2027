// Shrinks a large image in the browser so it fits the upload limit.
// Returns the original file if it is already small enough, a new JPEG file when shrunk,
// or null when the image could not be decoded / shrunk enough.

const MAX_SIDES = [2000, 1600, 1280, 1024, 800];
const QUALITIES = [0.85, 0.75, 0.65, 0.55];

async function decode(file: File): Promise<{ source: CanvasImageSource; width: number; height: number; release: () => void } | null> {
  try {
    if (typeof createImageBitmap === 'function') {
      const bitmap = await createImageBitmap(file);
      return { source: bitmap, width: bitmap.width, height: bitmap.height, release: () => bitmap.close() };
    }
  } catch {
    // fall back to <img>
  }
  const url = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const el = new Image();
      el.onload = () => resolve(el);
      el.onerror = () => reject(new Error('decode failed'));
      el.src = url;
    });
    return { source: img, width: img.naturalWidth, height: img.naturalHeight, release: () => URL.revokeObjectURL(url) };
  } catch {
    URL.revokeObjectURL(url);
    return null;
  }
}

function toBlob(canvas: HTMLCanvasElement, quality: number): Promise<Blob | null> {
  return new Promise((resolve) => canvas.toBlob((b) => resolve(b), 'image/jpeg', quality));
}

export async function compressImageToLimit(file: File, maxBytes: number): Promise<File | null> {
  if (file.size <= maxBytes) return file;
  const decoded = await decode(file);
  if (!decoded || !decoded.width || !decoded.height) return null;
  try {
    for (const maxSide of MAX_SIDES) {
      const scale = Math.min(1, maxSide / Math.max(decoded.width, decoded.height));
      const canvas = document.createElement('canvas');
      canvas.width = Math.max(1, Math.round(decoded.width * scale));
      canvas.height = Math.max(1, Math.round(decoded.height * scale));
      const ctx = canvas.getContext('2d');
      if (!ctx) return null;
      ctx.fillStyle = '#ffffff'; // flatten transparency (PNG) onto white
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(decoded.source, 0, 0, canvas.width, canvas.height);
      for (const quality of QUALITIES) {
        const blob = await toBlob(canvas, quality);
        if (blob && blob.size <= maxBytes) {
          const base = file.name.replace(/\.[^.]+$/, '') || 'image';
          return new File([blob], `${base}.jpg`, { type: 'image/jpeg', lastModified: Date.now() });
        }
      }
    }
    return null;
  } finally {
    decoded.release();
  }
}
