import { EVALUATION_FORMS, getRatingLabel } from '@/forms';
import { generateTeacherFeedback, type FeedbackItem } from '@/constants/criteriaFeedback';
import { LOGO_DATA_URI, SIGNATURE_DATA_URI, STAMP_DATA_URI } from '@/assets/schoolAssets';
import { DEPARTMENT_NAME, SCHOOL_NAME, PRINCIPAL_NAME, escapeHtml } from '@/school';
import type { User, Evaluation } from '@/types';

const FEEDBACK_STYLE = `
  @page { size: A4; margin: 10mm 12mm; }
  * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  html, body { margin: 0; padding: 0; }
  body { font-family: 'Segoe UI', Tahoma, 'Noto Naskh Arabic', Arial, sans-serif; color: #111; font-size: 11px; line-height: 1.55; }
  .teacher-page { display: flex; flex-direction: column; min-height: 268mm; page-break-after: always; break-after: page; }
  div.teacher-page:last-of-type { page-break-after: auto; break-after: auto; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111; padding-bottom: 6px; margin-bottom: 8px; }
  .header div { line-height: 1.7; font-weight: bold; font-size: 11px; }
  .logo { height: 54px; width: auto; display: block; margin: 0 auto; }
  h1 { text-align: center; font-size: 14.5px; margin: 4px 0 8px; }
  table { width: 100%; border-collapse: collapse; }
  .card td { border: 1px solid #444; padding: 4px 7px; }
  .card td.l { background: #e8e8e8; font-weight: bold; width: 17%; }
  .sec { margin-top: 8px; border: 1px solid #444; break-inside: avoid; page-break-inside: avoid; }
  .sec h2 { margin: 0; padding: 4px 8px; font-size: 12.5px; border-bottom: 1px solid #444; }
  .sec.s h2 { background: #dcfce7; } .sec.i h2 { background: #fef3c7; } .sec.r h2 { background: #dbeafe; }
  .sec ul { margin: 0; padding: 5px 22px 5px 8px; }
  .sec li { margin-bottom: 3px; }
  .sec li b { font-weight: bold; }
  .empty { padding: 6px 8px; color: #555; }
  .praise { padding: 6px 8px; font-weight: bold; background: #f0fdf4; border-bottom: 1px dashed #888; }
  .sign-wrap { margin-top: auto; padding-top: 10px; break-inside: avoid; page-break-inside: avoid; }
  .sign { display: flex; gap: 10px; align-items: stretch; }
  .box { flex: 1; border: 1px solid #444; padding: 7px 9px; min-height: 120px; }
  .box b { display: block; margin-bottom: 4px; font-size: 11.5px; }
  .box .row { margin-top: 9px; }
  .stamp-col { width: 150px; border: 1px solid #444; display: flex; align-items: center; justify-content: center; padding: 4px; }
  .stamp-frame { width: 104px; height: 104px; border: 2px dashed #777; border-radius: 50%; display: flex; align-items: center; justify-content: center; text-align: center; font-size: 10px; color: #555; padding: 10px; }
  .stamp-col img { max-width: 140px; height: auto; }
  .sig-img { height: 46px; width: auto; display: block; margin-top: 2px; }
  .foot { text-align: center; font-size: 9px; color: #666; margin-top: 4px; }
`;

const listHtml = (items: FeedbackItem[]): string =>
  `<ul>${items.map((i) => `<li><b>${escapeHtml(i.name)}:</b> ${escapeHtml(i.text)}</li>`).join('')}</ul>`;

export interface FeedbackOptions {
  /** إظهار التوقيع والختم حتى لو لم يُعتمد التقييم */
  forceSeal?: boolean;
  /** إن لم يوجد تقييم معتمد: استخدم آخر تقييم غير معتمد (مسودة/محفوظ) بدل تخطي المعلم */
  includeUnapproved?: boolean;
}

/**
 * يرجع صفحة معلم واحدة، أو null.
 * الأولوية: النهائي المعتمد، ثم النصف سنوي المعتمد.
 * وإن لم يوجد معتمد فلا تُطبع إلا إذا فُعّل includeUnapproved (فيؤخذ النهائي ثم النصف سنوي بما فيهما من درجات).
 */
export function buildFeedbackSection(emp: User, evals: Evaluation[], options: FeedbackOptions = {}): string | null {
  const pick = (period: Evaluation['period'], approvedOnly: boolean) =>
    evals.find((e) => e.period === period && !!e.scores?.length && (!approvedOnly || e.status === 'approved'));
  const ev = pick('final', true) || pick('midyear', true)
    || (options.includeUnapproved ? pick('final', false) || pick('midyear', false) : undefined);
  if (!ev || !ev.scores?.length) return null;
  const periodLabel = `${ev.period === 'final' ? 'التقييم النهائي' : 'التقييم النصف سنوي'} (${ev.status === 'approved' ? 'معتمد' : 'غير معتمد'})`;

  const form = EVALUATION_FORMS[emp.formType || 'teacher'];
  const maxTotal = form.criteria.reduce((s, c) => s + c.weight, 0);
  const total = form.criteria.reduce((s, c) => {
    const r = ev.scores?.find((x) => x.criterionId === c.id)?.rating || 0;
    return s + (r ? (r / 5) * c.weight : 0);
  }, 0);
  const percent = maxTotal ? (total / maxTotal) * 100 : 0;
  const feedback = generateTeacherFeedback(ev.scores, form.criteria);
  const sealed = !!options.forceSeal || ev.status === 'approved';

  const strengthsBody = feedback.allPerfect
    ? `<div class="praise">${escapeHtml(feedback.generalPraise)}</div>${feedback.strengths.length ? listHtml(feedback.strengths) : ''}`
    : feedback.strengths.length
      ? listHtml(feedback.strengths)
      : '<div class="empty">لم يحقق المعلم الدرجة الكاملة في أي معيار خلال هذه الفترة، ويُنصح بالتركيز على مجالات التطوير الموضحة أدناه.</div>';
  const improvementsBody = feedback.improvements.length
    ? listHtml(feedback.improvements)
    : '<div class="empty">لا توجد مجالات تطوير؛ جميع المعايير المقيَّمة بالدرجة الكاملة.</div>';

  return `<div class="teacher-page">
  <div class="header">
    <div>المملكة العربية السعودية<br/>وزارة التعليم<br/>${DEPARTMENT_NAME}<br/>${SCHOOL_NAME}</div>
    <div><img class="logo" src="${LOGO_DATA_URI}" alt="" /></div>
    <div>التاريخ: ......../......../........ هـ</div>
  </div>
  <h1>استمارة التغذية الراجعة وخطة التطوير المهني لشاغلي الوظائف التعليمية</h1>

  <table class="card">
    <tr><td class="l">الاسم</td><td>${escapeHtml(emp.fullName)}</td><td class="l">السجل المدني</td><td>${escapeHtml(emp.civilId)}</td></tr>
    <tr><td class="l">التخصص</td><td>${escapeHtml(emp.jobTitle || form.shortName)}</td><td class="l">الفترة</td><td>${periodLabel}</td></tr>
    <tr><td class="l">الدرجة النهائية</td><td>${total.toFixed(1)} من ${maxTotal} (${percent.toFixed(1)}%)</td><td class="l">التقدير العام</td><td><b>${getRatingLabel((percent / 100) * 5)}</b></td></tr>
  </table>

  <div class="sec s"><h2>أ) نقاط القوة البارزة</h2>${strengthsBody}</div>
  <div class="sec i"><h2>ب) مجالات وفرص التطوير</h2>${improvementsBody}</div>
  <div class="sec r"><h2>ج) التوصيات الإجرائية المقترحة وخطة النمو المهني</h2>${listHtml(feedback.recommendations)}</div>

  <div class="sign-wrap">
    <div class="sign">
      <div class="box">
        <b>الطرف الأول: المعلم (المقر بالعلم والاستلام)</b>
        <div class="row">الاسم: ${escapeHtml(emp.fullName)}</div>
        <div class="row">التوقيع: ........................</div>
        <div class="row">التاريخ: .... / .... / 144..هـ</div>
      </div>
      <div class="box">
        <b>الطرف الثاني: المدير المباشر (مدير المدرسة)</b>
        <div class="row">الاسم: ${PRINCIPAL_NAME}</div>
        ${sealed
          ? `<div class="row">التوقيع: <img class="sig-img" src="${SIGNATURE_DATA_URI}" alt="" /></div>`
          : '<div class="row">التوقيع: ........................</div>'}
        <div class="row">التاريخ: .... / .... / 144..هـ</div>
      </div>
      <div class="stamp-col">
        ${sealed ? `<img src="${STAMP_DATA_URI}" alt="" />` : '<div class="stamp-frame">ختم المدرسة الرسمي</div>'}
      </div>
    </div>
    <div class="foot">استمارة رسمية صادرة من نظام تقييم الأداء الوظيفي - ${SCHOOL_NAME}</div>
  </div>
</div>`;
}

export function wrapFeedbackHtml(title: string, sections: string[]): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8" />
<title>${escapeHtml(title)}</title>
<style>${FEEDBACK_STYLE}</style></head><body>
${sections.join('\n')}
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 400); };</script>
</body></html>`;
}
