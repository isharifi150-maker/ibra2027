import { EVALUATION_FORMS, getRatingLabel } from '@/forms';
import { LOGO_DATA_URI, SIGNATURE_DATA_URI, STAMP_DATA_URI } from '@/assets/schoolAssets';
import { DEPARTMENT_NAME, SCHOOL_NAME, PRINCIPAL_NAME, escapeHtml } from '@/school';
import { formatDateShort, formatFileSize } from '@/utils';
import type { User, Evaluation, Evidence } from '@/types';

const COMPREHENSIVE_STYLE = `
  @page { size: A4; margin: 12mm 12mm 16mm; @bottom-center { content: "صفحة " counter(page) " من " counter(pages); font-size: 10px; color: #555; } }
  * { box-sizing: border-box; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  body { font-family: 'Segoe UI', Tahoma, 'Noto Naskh Arabic', Arial, sans-serif; color: #111; font-size: 12px; margin: 0; line-height: 1.5; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 10px; }
  .header div { line-height: 1.8; font-weight: bold; }
  .logo { height: 62px; width: auto; display: block; margin: 0 auto; }
  h1 { text-align: center; font-size: 17px; margin: 6px 0 10px; }
  h2 { font-size: 14px; margin: 14px 0 6px; padding-bottom: 3px; border-bottom: 1px solid #999; break-after: avoid; page-break-after: avoid; }
  table { width: 100%; border-collapse: collapse; margin-bottom: 10px; }
  th, td { border: 1px solid #444; padding: 4px 6px; vertical-align: top; overflow-wrap: anywhere; word-break: break-word; }
  th { background: #ddd; }
  thead { display: table-header-group; }
  tr { break-inside: avoid; page-break-inside: avoid; }
  td.c, th.c { text-align: center; }
  .info td.l { background: #eee; font-weight: bold; width: 18%; }
  tr.total td { background: #f1f1f1; font-weight: bold; }
  .notes { border: 1px solid #444; padding: 6px 8px; margin-bottom: 8px; break-inside: avoid; page-break-inside: avoid; }
  a { color: #0b4f9c; text-decoration: underline; }
  ul.files { margin: 0; padding: 0 16px 0 0; }
  ul.files li { margin-bottom: 2px; }
  .muted { color: #666; }
  .sign { display: flex; gap: 20px; margin-top: 18px; break-inside: avoid; page-break-inside: avoid; }
  .sign .box { flex: 1; border: 1px solid #444; padding: 10px; min-height: 110px; }
  .sign .box b { display: block; margin-bottom: 6px; }
  .seal { display: flex; align-items: center; gap: 10px; margin-top: 6px; }
  .seal .sig { height: 55px; width: auto; } .seal .stamp { height: 85px; width: auto; }
  .emp { break-after: page; page-break-after: always; }
  div.emp:last-of-type { break-after: auto; page-break-after: auto; }
  @media print { .no-print { display: none !important; } }
`;

const safeUrl = (u: string): string => (/^https?:\/\//i.test(u) ? u : '');

export function buildComprehensiveSection(emp: User, evals: Evaluation[], evidence: Evidence[]): string {
  const form = EVALUATION_FORMS[emp.formType || 'teacher'];
  const mid = evals.find((e) => e.period === 'midyear');
  const fin = evals.find((e) => e.period === 'final');
  const maxTotal = form.criteria.reduce((s, c) => s + c.weight, 0);

  const managerRating = (ev: Evaluation | undefined, id: string): number | null => {
    const sc = ev?.scores?.find((x) => x.criterionId === id);
    return sc && sc.rating ? sc.rating : null;
  };
  const selfRating = (ev: Evaluation | undefined, id: string): number | null => {
    const sc = ev?.selfScores?.find((x) => x.criterionId === id);
    return sc && sc.rating ? sc.rating : null;
  };
  const percent = (get: (id: string) => number | null, any: boolean): number | null => {
    if (!any) return null;
    const total = form.criteria.reduce((s, c) => {
      const r = get(c.id);
      return s + (r ? (r / 5) * c.weight : 0);
    }, 0);
    return maxTotal ? (total / maxTotal) * 100 : 0;
  };
  const cols = {
    self: percent((id) => selfRating(fin, id) ?? selfRating(mid, id), !!(fin?.selfScores?.length || mid?.selfScores?.length)),
    mid: percent((id) => managerRating(mid, id), !!mid?.scores?.length),
    fin: percent((id) => managerRating(fin, id), !!fin?.scores?.length),
  };
  const pctText = (p: number | null) => (p === null ? '—' : `${p.toFixed(1)}%`);
  const lblText = (p: number | null) => (p === null ? '—' : getRatingLabel((p / 100) * 5));

  const rows = form.criteria.map((c, i) => `<tr>
    <td class="c">${i + 1}</td>
    <td>${escapeHtml(c.label)}</td>
    <td class="c">${c.weight}</td>
    <td class="c">${selfRating(fin, c.id) ?? selfRating(mid, c.id) ?? '—'}</td>
    <td class="c">${managerRating(mid, c.id) ?? '—'}</td>
    <td class="c">${managerRating(fin, c.id) ?? '—'}</td>
  </tr>`).join('');

  const evidenceRows = form.criteria.map((c, i) => {
    const files = evidence.filter((e) => e.criterionId === c.id);
    const list = files.length
      ? `<ul class="files">${files.map((f) => {
          const url = safeUrl(f.fileData);
          const name = escapeHtml(f.fileName);
          return `<li>${url ? `<a href="${escapeHtml(url)}">${name}</a>` : name} <span class="muted">(${f.fileType === 'pdf' ? 'PDF' : 'صورة'} • ${formatFileSize(f.fileSize)} • ${formatDateShort(f.uploadedAt)})</span></li>`;
        }).join('')}</ul>`
      : '<span class="muted">لا توجد شواهد</span>';
    return `<tr><td class="c">${i + 1}</td><td>${escapeHtml(c.label)}</td><td>${list}</td><td class="c">${files.length}</td></tr>`;
  }).join('');

  const noteBlock = (title: string, text?: string) =>
    text && text.trim() ? `<div class="notes"><b>${title}:</b> ${escapeHtml(text.trim())}</div>` : '';
  const notes = noteBlock('ملاحظات المدير (النصف سنوي)', mid?.generalNotes)
    + noteBlock('ملاحظات المدير (النهائي)', fin?.generalNotes)
    + noteBlock('ملاحظات المعلم (تقييم ذاتي)', fin?.selfNotes || mid?.selfNotes);

  const approved = fin?.status === 'approved';

  return `<div class="emp">
  <div class="header">
    <div>المملكة العربية السعودية<br/>وزارة التعليم<br/>${DEPARTMENT_NAME}<br/>${SCHOOL_NAME}</div>
    <div><img class="logo" src="${LOGO_DATA_URI}" alt="" /></div>
    <div>التاريخ: ......../......../........ هـ</div>
  </div>
  <h1>استمارة تقييم الأداء الوظيفي الشاملة</h1>

  <table class="info">
    <tr><td class="l">الاسم</td><td>${escapeHtml(emp.fullName)}</td><td class="l">السجل المدني</td><td>${escapeHtml(emp.civilId)}</td></tr>
    <tr><td class="l">المسمى الوظيفي / التخصص</td><td>${escapeHtml(emp.jobTitle || form.shortName)}</td><td class="l">نموذج التقييم</td><td>${escapeHtml(form.name)}</td></tr>
  </table>

  <h2>أولاً: الدرجات (ذاتي • نصف سنوي • نهائي)</h2>
  <table>
    <thead><tr><th class="c" style="width:6%">م</th><th>معيار الأداء</th><th class="c" style="width:9%">الوزن</th><th class="c" style="width:13%">ذاتي</th><th class="c" style="width:13%">نصف سنوي</th><th class="c" style="width:13%">نهائي</th></tr></thead>
    <tbody>
      ${rows}
      <tr class="total"><td colspan="2">النسبة المئوية</td><td class="c">${maxTotal}</td><td class="c">${pctText(cols.self)}</td><td class="c">${pctText(cols.mid)}</td><td class="c">${pctText(cols.fin)}</td></tr>
      <tr class="total"><td colspan="2">التقدير</td><td class="c"></td><td class="c">${lblText(cols.self)}</td><td class="c">${lblText(cols.mid)}</td><td class="c">${lblText(cols.fin)}</td></tr>
    </tbody>
  </table>
  <p class="muted" style="margin:0 0 6px">التقدير من 1 إلى 5 لكل بند. التقييم الذاتي تقديري من المعلم للمقارنة، ولا يدخل في الدرجة المعتمدة.</p>
  ${notes}

  <h2>ثانياً: الشواهد المرفوعة (${evidence.length} ملف)</h2>
  <table>
    <thead><tr><th class="c" style="width:6%">م</th><th style="width:30%">البند</th><th>الشواهد</th><th class="c" style="width:9%">العدد</th></tr></thead>
    <tbody>${evidenceRows}</tbody>
  </table>

  <div class="sign">
    <div class="box"><b>المعلم / الموظف</b>الاسم: ${escapeHtml(emp.fullName)}<div style="margin-top:22px">التوقيع: ..............................</div><div style="margin-top:14px">التاريخ: ..............................</div></div>
    <div class="box"><b>مدير المدرسة</b>الاسم: ${PRINCIPAL_NAME}${approved
      ? `<div class="seal"><img class="sig" src="${SIGNATURE_DATA_URI}" alt="" /><img class="stamp" src="${STAMP_DATA_URI}" alt="" /></div>`
      : `<div style="margin-top:22px">التوقيع: ..............................</div><div style="margin-top:14px">الاعتماد / الختم: ..............................</div>`}</div>
  </div>
</div>`;
}

export function wrapComprehensiveHtml(title: string, sections: string[]): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl"><head><meta charset="UTF-8" />
<title>${escapeHtml(title)}</title>
<style>${COMPREHENSIVE_STYLE}</style></head><body>
${sections.join('\n')}
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 400); };</script>
</body></html>`;
}

export function buildComprehensiveHtml(emp: User, evals: Evaluation[], evidence: Evidence[]): string {
  return wrapComprehensiveHtml(`الاستمارة الشاملة - ${emp.fullName}`, [buildComprehensiveSection(emp, evals, evidence)]);
}
