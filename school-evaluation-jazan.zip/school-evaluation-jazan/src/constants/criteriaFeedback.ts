export interface CriterionFeedback {
  id: string;
  name: string;
  strengthText: string;
  improvementText: string;
  recommendation: string;
}

export const CRITERIA_FEEDBACK_GUIDE: CriterionFeedback[] = [
  {
    id: "c1",
    name: "إعداد وتنفيذ خطة التعلم",
    strengthText: "تميز في إعداد خطة تعليمية محكمة تتوافق مع التوجهات والسياسات التعليمية وتلبي متطلبات المنهج ونواتجه بدقة.",
    improvementText: "الحاجة إلى تطوير إعداد خطة التعلم لتستند بوضوح إلى تشخيص واقع المتعلمين ومستوياتهم التحصيلية.",
    recommendation: "مواءمة خطط التحضير الأسبوعية مع مؤشرات نتائج التقويم التشخيصي والتغذية الراجعة التكوينية."
  },
  {
    id: "c2",
    name: "التنويع في استراتيجيات التدريس",
    strengthText: "مهارة عالية في توظيف استراتيجيات تعلم نشط متنوعة تحفز التفكير الناقد وحل المشكلات وتعزز مشاركة المتعلمين.",
    improvementText: "الاعتماد الغالب على أسلوب الإلقاء المباشر ومحدودية تطبيق استراتيجيات تدريس تفاعلية متمركزة حول الطالب.",
    recommendation: "إدراج استراتيجيات مثل (التعلم القائم على المشاريع، العصف الذهني، واستقصاء المفاهيم) في خطط الدروس."
  },
  {
    id: "c3",
    name: "توظيف التقنيات ووسائل التعلم المناسبة",
    strengthText: "إدماج فعّال ومبتكر للتقنيات التعليمية والمنصات الرقمية لتعزيز فاعلية المواقف التعليمية وفهم الطلاب.",
    improvementText: "الحاجة إلى تعزيز استخدام الوسائل الرقمية والتطبيقات التفاعلية الحديثة لدعم عمليتي التعليم والتعلم.",
    recommendation: "توظيف الأدوات التعليمية التفاعلية وتطبيقات الفصول الافتراضية والمنصات التعليمية المعتمدة."
  },
  {
    id: "c4",
    name: "تنوع أساليب وأدوات التقويم",
    strengthText: "كفاءة في تطبيق أدوات تقويم بنائية وختامية متوازنة وشاملة تقيس مستويات الفهم والمهارات التطبيقية.",
    improvementText: "الاقتصار على أدوات التقويم التقليدية دون تنويع في أدوات الملاحظة وسلالم التقدير والتقويم التكويني المستمر.",
    recommendation: "تصميم واستخدام سلالم التقدير اللفظية (Rubrics) وملفات الإنجاز وبنوك الأسئلة المتدرجة الصعوبة."
  },
  {
    id: "c5",
    name: "تحسين نتائج المتعلمين ونواتج التعلم",
    strengthText: "أثر ملموس في رفع مستوى التحصيل الدراسي لدى الطلاب وتقديم تغذية راجعة فورية ومحددة لمعالجة الفجوات.",
    improvementText: "الحاجة إلى التدخل العلاجي المنتظم للطلاب المتعثرين ومتابعة سد فجوات الفاقد التعليمي بدقة.",
    recommendation: "بناء خطط علاجية وإثرائية قائمة على تحليل المهارات والفاقد التعليمي وتوثيق تقدم المتعلمين."
  },
  {
    id: "c6",
    name: "تحليل نتائج المتعلمين لتطوير التعلم",
    strengthText: "قدرة متميزة على استخلاص الحقائق والاستنتاجات من نتائج الاختبارات لرسم مسارات التدريس المستقبلي.",
    improvementText: "قلة الاعتماد على تحليل البيانات الإحصائية للاختبارات في تحديد أولويات التدريس داخل الفصل.",
    recommendation: "حضور ورشة عمل في قراءة وتحليل نتائج الاختبارات لتوجيه عمليات التدريس والتقويم."
  },
  {
    id: "c7",
    name: "تهيئة بيئة تعليمية محفزة والإدارة الصفية",
    strengthText: "نجاح في خلق بيئة صفية إيجابية وآمنة تسودها قيم الاحترام المتبادل وتعزز الانضباط الذاتي للطلاب.",
    improvementText: "الحاجة إلى تعزيز قواعد الضبط الإيجابي وإشاعة التفاعل النشط داخل الحصة لمعالجة تشتت الانتباه.",
    recommendation: "تفعيل ميثاق البيئة الصفية المحفزة وأساليب التعزيز الإيجابي اللفظي والمعنوي."
  },
  {
    id: "c8",
    name: "مراعاة الفروق الفردية ورعاية الطلاب",
    strengthText: "تصميم مواقف تعليمية تراعي تمايز قدرات واهتمامات المتعلمين وتتيح فرص تعلم متكافئة للجميع.",
    improvementText: "تقديم المهمات والأنشطة التعليمية بنسق واحد دون مراعاة لتفاوت قدرات الموهوبين أو المتعثرين.",
    recommendation: "تطبيق استراتيجيات التعليم المتمايز وتوفير أنشطة متدرجة المستويات ومهمات إثرائية."
  },
  {
    id: "c9",
    name: "التطوير المهني المستمر والتعلم الذاتي",
    strengthText: "التزام واضح بحضور برامج التطوير المهني وتطبيق الممارسات التدريسية الحديثة وتبادل الخبرات.",
    improvementText: "محدودية المشاركة في مجتمعات التعلم المهنية أو برامج التطوير المهني التخصصية.",
    recommendation: "الالتحاق بالبرامج المعتمدة في منصات التدريب الوزارية وتفعيل الزيارات التبادلية مع الزملاء."
  },
  {
    id: "c10",
    name: "الانضباط المهني والالتزام بالأنظمة التعليمية",
    strengthText: "امتثال عالٍ بأخلاقيات مهنة التعليم، والالتزام بمواعيد المهام، والتعاون الإيجابي مع الإدارة المدرسية.",
    improvementText: "التفاوت في الالتزام بتسليم التقارير أو متابعة الأعمال المنوطة في مواعيدها المحددة.",
    recommendation: "تنظيم المهام بجدول إنجاز دوري والالتزام بالتقويم الزمني المعتمد للأعمال المدرسية."
  },
  {
    id: "c11",
    name: "التواصل الإيجابي مع أولياء الأمور والمجتمع",
    strengthText: "تواصل دوري ومنهجي مع أولياء الأمور وتزويدهم بملحوظات دقيقة حول مستوى تقدم أبنائهم.",
    improvementText: "الحاجة إلى تفعيل قنوات التواصل النظامية لإشراك الأسرة في مسيرة تعلم الطالب ومستواه السلوكي والأكاديمي.",
    recommendation: "جدولة تقارير تقدم دورية وتفعيل المنصات المدرسية المعتمدة لتعزيز الشراكة مع الأسرة."
  }
];

// ---------------------------------------------------------------------------
// قواعد التحليل (يمكن تعديلها من هنا)
// ---------------------------------------------------------------------------
/** الدرجة التي تُعدّ "تميزاً" وتدخل في نقاط القوة (من 5). ما دونها يدخل في مجالات التطوير. */
export const STRENGTH_MIN_RATING = 5;

/** ربط معايير النظام (t1..t11 وغيرها) بمعايير المصفوفة أعلاه عبر كلمات من اسم المعيار. الترتيب مهم. */
const CRITERION_MATCH_KEYWORDS: [string, string[]][] = [
  ["c6", ["تحليل نتائج"]],
  ["c5", ["تحسين نتائج", "نواتج التعلم"]],
  ["c1", ["خطة التعلم"]],
  ["c2", ["استراتيجيات التدريس"]],
  ["c3", ["تقنيات", "وسائل التعلم"]],
  ["c4", ["أساليب التقويم", "أدوات التقويم"]],
  ["c7", ["بيئة تعليمية", "الإدارة الصفية"]],
  ["c8", ["الفروق الفردية"]],
  ["c9", ["التطوير المهني", "المجتمع المهني"]],
  ["c10", ["الانضباط المهني", "الواجبات الوظيفية"]],
  ["c11", ["أولياء الأمور"]],
];

export interface FeedbackCriterionRef { id: string; label: string }
export interface FeedbackItem { criterionId: string; name: string; text: string; rating: number }

export interface TeacherFeedback {
  strengths: FeedbackItem[];
  improvements: FeedbackItem[];
  recommendations: FeedbackItem[];
  /** كل المعايير المقيَّمة حصلت على الدرجة الكاملة */
  allPerfect: boolean;
  /** ثناء عام يظهر عند تحقق الدرجة الكاملة في كل المعايير */
  generalPraise: string;
}

export const ALL_PERFECT_PRAISE =
  "حقق المعلم الدرجة الكاملة في جميع معايير الأداء الوظيفي، ويُشكر على تميزه وعطائه المهني وأثره الإيجابي في بيئة المدرسة.";
export const ALL_PERFECT_RECOMMENDATION =
  "المحافظة على مستوى التميز الحالي، والمبادرة بنقل الخبرة للزملاء عبر ورش العمل ومجتمعات التعلم المهنية والزيارات التبادلية.";

/** يجد معيار المصفوفة المناسب لمعيار في النظام (بالمعرّف أو بكلمات من الاسم). */
export function findGuideForCriterion(ref: FeedbackCriterionRef): CriterionFeedback | undefined {
  const byId = CRITERIA_FEEDBACK_GUIDE.find((g) => g.id === ref.id);
  if (byId) return byId;
  for (const [guideId, keywords] of CRITERION_MATCH_KEYWORDS) {
    if (keywords.some((k) => ref.label.includes(k))) {
      return CRITERIA_FEEDBACK_GUIDE.find((g) => g.id === guideId);
    }
  }
  return undefined;
}

type ScoresInput = Record<string, number> | { criterionId: string; rating: number }[];

// دالة التحليل الذكي:
// - الدرجة الكاملة (5 من 5) → نقاط القوة.
// - 4 فما دون → مجالات التطوير + التوصية المقترحة.
// - إذا كانت كل الدرجات كاملة → ثناء عام وتوصية بالمحافظة على التميز ونقل الخبرة.
// المعامل الثاني اختياري: معايير نموذج المعلم في النظام (لربطها بنصوص المصفوفة وترتيبها).
export function generateTeacherFeedback(scores: ScoresInput, criteria?: FeedbackCriterionRef[]): TeacherFeedback {
  const ratings = new Map<string, number>();
  if (Array.isArray(scores)) {
    scores.forEach((s) => { if (s && s.criterionId) ratings.set(String(s.criterionId), Number(s.rating) || 0); });
  } else {
    Object.entries(scores || {}).forEach(([id, rating]) => ratings.set(id, Number(rating) || 0));
  }

  const refs: FeedbackCriterionRef[] = criteria && criteria.length
    ? criteria
    : CRITERIA_FEEDBACK_GUIDE.filter((g) => ratings.has(g.id)).map((g) => ({ id: g.id, label: g.name }));

  const strengths: FeedbackItem[] = [];
  const improvements: FeedbackItem[] = [];
  const recommendations: FeedbackItem[] = [];
  const seen = new Set<string>(); // يمنع تكرار نفس النص عندما يرتبط معياران بنفس بند المصفوفة
  let rated = 0;

  refs.forEach((ref) => {
    const rating = ratings.get(ref.id) || 0;
    if (!rating) return; // معيار غير مقيَّم
    rated += 1;
    const guide = findGuideForCriterion(ref);
    const name = guide ? guide.name : ref.label;

    if (rating >= STRENGTH_MIN_RATING) {
      const key = `s:${guide?.id || ref.id}`;
      if (seen.has(key)) return;
      seen.add(key);
      strengths.push({
        criterionId: ref.id, name, rating,
        text: guide ? guide.strengthText : `أداء متميز في معيار «${ref.label}» وفق مؤشرات الأداء المعتمدة.`,
      });
      return;
    }

    const key = `i:${guide?.id || ref.id}`;
    if (seen.has(key)) return;
    seen.add(key);
    improvements.push({
      criterionId: ref.id, name, rating,
      text: guide ? guide.improvementText : `الحاجة إلى تطوير الأداء في معيار «${ref.label}» ومواءمته مع مؤشرات الأداء المعتمدة.`,
    });
    recommendations.push({
      criterionId: ref.id, name, rating,
      text: guide ? guide.recommendation : `وضع خطة تطوير مهني لمعيار «${ref.label}» ومتابعتها مع المدير المباشر.`,
    });
  });

  const allPerfect = rated > 0 && improvements.length === 0;
  if (allPerfect) {
    recommendations.push({ criterionId: "all", name: "المحافظة على التميز", rating: 5, text: ALL_PERFECT_RECOMMENDATION });
  }

  return { strengths, improvements, recommendations, allPerfect, generalPraise: allPerfect ? ALL_PERFECT_PRAISE : "" };
}
