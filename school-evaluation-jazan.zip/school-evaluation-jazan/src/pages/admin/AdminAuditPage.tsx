import { useCallback, useEffect, useState } from 'react';
import { History, RefreshCw, Download } from 'lucide-react';
import { getAuditLog, buildBackup, logAudit, type AuditEntry } from '@/db';
import { useAuth } from '@/context/AuthContext';
import { toast } from '@/components/ui/Toast';
import { downloadBytes } from '@/xlsx';
import { formatDate } from '@/utils';
import { todayStamp } from '@/school';

export function AdminAuditPage() {
  const { user } = useAuth();
  const [entries, setEntries] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [backingUp, setBackingUp] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      setEntries(await getAuditLog(200));
    } catch (e) {
      setError(e instanceof Error ? e.message : 'تعذر تحميل السجل');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleBackup = async () => {
    setBackingUp(true);
    try {
      const backup = await buildBackup();
      const bytes = new TextEncoder().encode(JSON.stringify(backup, null, 2));
      downloadBytes(`backup-${todayStamp()}.json`, bytes, 'application/json');
      void logAudit(user, 'تنزيل نسخة احتياطية');
      toast('success', 'تم تنزيل النسخة الاحتياطية');
    } catch (e) {
      toast('error', e instanceof Error ? e.message : 'تعذر إنشاء النسخة الاحتياطية');
    } finally { setBackingUp(false); }
  };

  return (
    <div className="space-y-6">
      <div className="card space-y-3">
        <h3 className="text-base font-bold text-neutral-800">نسخة احتياطية</h3>
        <p className="text-xs leading-relaxed text-neutral-500">
          تنزّل ملفاً واحداً فيه بيانات الموظفين والتقييمات والدرجات وروابط الشواهد.
          كلمات المرور لا تُضمَّن، وملفات الشواهد نفسها تبقى محفوظة في Supabase.
        </p>
        <button onClick={handleBackup} disabled={backingUp} className="btn-primary w-full sm:w-auto">
          <Download size={16} /> {backingUp ? 'جاري التجهيز...' : 'تنزيل نسخة احتياطية'}
        </button>
      </div>

      <div className="card">
        <div className="mb-4 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <History size={20} className="text-primary-600" />
            <h3 className="text-base font-bold text-neutral-800">سجل العمليات (آخر 200)</h3>
          </div>
          <button onClick={load} disabled={loading} className="btn-outline text-xs"><RefreshCw size={14} className={loading ? 'animate-spin' : ''} /> تحديث</button>
        </div>

        {error ? (
          <p className="rounded-xl border border-warning-300 bg-warning-50 px-4 py-3 text-sm leading-relaxed text-warning-800">{error}</p>
        ) : entries.length === 0 ? (
          <p className="py-8 text-center text-sm text-neutral-500">{loading ? 'جاري التحميل...' : 'لا توجد عمليات مسجلة بعد'}</p>
        ) : (
          <ul className="divide-y divide-neutral-100">
            {entries.map((e) => (
              <li key={e.id} className="py-3">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <span className="text-sm font-bold text-neutral-800">{e.action}</span>
                  <span className="text-xs text-neutral-400">{formatDate(e.createdAt)}</span>
                </div>
                <p className="text-xs text-neutral-500">{e.actorName || 'غير معروف'}</p>
                {e.details && <p className="mt-1 break-words text-xs text-neutral-600">{e.details}</p>}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
