import { useEffect, useState, useCallback } from 'react';
import {
  ClipboardList, FileText, Eye, Star, Save, CheckCircle2, Award,
  MessageSquare, Lock, Unlock
} from 'lucide-react';
import { EVALUATION_FORMS, RATING_LABELS, getRatingLabel, getRatingLabelFromTotal, getRatingColorFromTotal } from '@/forms';
import {
  getAllUsers, getEvidenceByUser, getScoresByPeriod, saveScore,
  getEvaluation, saveEvaluation, reopenEvaluation, logAudit
} from '@/db';
import { useAuth } from '@/context/AuthContext';
import { FilePreviewModal, EvidenceFileCard, EmptyState } from '@/components/ui/FilePreview';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { Modal } from '@/components/ui/Modal';
import { toast } from '@/components/ui/Toast';
import { generateId, formatDate } from '@/utils';
import type { User, Evidence, Score, Evaluation } from '@/types';

export function AdminEvaluationPage() {
  const { user: actor } = useAuth();
  const [employees, setEmployees] = useState<User[]>([]);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [period, setPeriod] = useState<'midyear' | 'final'>('midyear');
  const [evidence, setEvidence] = useState<Evidence[]>([]);
  const [scores, setScores] = useState<Score[]>([]);
  const [evaluation, setEvaluation] = useState<Evaluation | null>(null);
  const [previewEvidence, setPreviewEvidence] = useState<Evidence | null>(null);
  const [generalNotes, setGeneralNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(true);
  const [reopenOpen, setReopenOpen] = useState(false);
  const [reopenReason, setReopenReason] = useState('');

  const loadEmployees = useCallback(async () => {
    try {
      const users = await getAllUsers();
      const emps = users.filter((u) => u.role === 'employee');
      setEmployees(emps);
      if (emps.length > 0 && !selectedUserId) setSelectedUserId(emps[0].id);
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر مزامنة قائمة الموظفين');
    }
  }, [selectedUserId]);

  useEffect(() => { loadEmployees(); }, [loadEmployees]);

  const loadData = useCallback(async () => {
    if (!selectedUserId) { setSyncing(false); return; }
    setSyncing(true);
    try {
      const [ev, sc, evalData] = await Promise.all([
        getEvidenceByUser(selectedUserId),
        getScoresByPeriod(selectedUserId, period),
        getEvaluation(selectedUserId, period),
      ]);
      setEvidence(ev);
      setScores(sc);
      setEvaluation(evalData || null);
      setGeneralNotes(evalData?.generalNotes || '');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر مزامنة بيانات التقييم');
    } finally { setSyncing(false); }
  }, [selectedUserId, period]);

  useEffect(() => { loadData(); }, [loadData]);

  const selectedUser = employees.find((e) => e.id === selectedUserId);
  const form = selectedUser?.formType ? EVALUATION_FORMS[selectedUser.formType] : null;

  const getScore = (criterionId: string): Score | undefined =>
    scores.find((s) => s.criterionId === criterionId);

  const updateScore = async (criterionId: string, rating: number, notes: string) => {
    if (!selectedUserId) return;
    if (evaluation?.status === 'approved') {
      toast('error', 'التقييم معتمد ومقفل. اضغط «إلغاء الاعتماد» أولاً للتعديل');
      return;
    }
    setLoading(true);
    try {
    const existing = getScore(criterionId);
    if (existing) {
      const updated = { ...existing, rating, notes, updatedAt: Date.now() };
      await saveScore(updated);
    } else {
      const newScore: Score = {
        id: generateId(),
        userId: selectedUserId,
        criterionId,
        rating,
        notes,
        period,
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      await saveScore(newScore);
    }
    const criterionLabel = form?.criteria.find((c) => c.id === criterionId)?.label || criterionId;
    void logAudit(actor, 'تعديل درجة بند', `${selectedUser?.fullName || ''} | ${period === 'midyear' ? 'نصف سنوي' : 'نهائي'} | ${criterionLabel} | التقدير: ${rating}`);
    await loadData();
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'فشل حفظ درجة البند');
    } finally { setLoading(false); }
  };

  const calculateTotal = (): number => {
    if (!form) return 0;
    let total = 0;
    for (const criterion of form.criteria) {
      const score = getScore(criterion.id);
      if (score) {
        total += (score.rating / 5) * criterion.weight;
      }
    }
    return total;
  };

  const handleSaveDraft = async () => {
    if (!selectedUserId || !form) return;
    setLoading(true);
    try {
      const total = calculateTotal();
      const existing = await getEvaluation(selectedUserId, period);
      const evalData: Evaluation = {
        id: existing?.id || generateId(),
        userId: selectedUserId,
        period,
        status: existing?.status === 'approved' ? 'approved' : 'submitted',
        generalNotes,
        totalScore: total,
        ratingLabel: getRatingLabelFromTotal(total),
        approvedAt: existing?.approvedAt,
        createdAt: existing?.createdAt || Date.now(),
        updatedAt: Date.now(),
      };
      await saveEvaluation(evalData);
      void logAudit(actor, 'حفظ تقييم', `${selectedUser?.fullName || ''} | ${period === 'midyear' ? 'نصف سنوي' : 'نهائي'} | المجموع: ${total.toFixed(2)}`);
      await loadData();
      toast('success', 'تم حفظ التقييم');
    } catch {
      toast('error', 'فشل حفظ التقييم');
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async () => {
    if (!selectedUserId || !form) return;
    setLoading(true);
    try {
      const total = calculateTotal();
      const existing = await getEvaluation(selectedUserId, period);
      const evalData: Evaluation = {
        id: existing?.id || generateId(),
        userId: selectedUserId,
        period,
        status: 'approved',
        generalNotes,
        totalScore: total,
        ratingLabel: getRatingLabelFromTotal(total),
        approvedAt: Date.now(),
        createdAt: existing?.createdAt || Date.now(),
        updatedAt: Date.now(),
      };
      await saveEvaluation(evalData);
      void logAudit(actor, 'اعتماد تقييم', `${selectedUser?.fullName || ''} | ${period === 'midyear' ? 'نصف سنوي' : 'نهائي'} | المجموع: ${total.toFixed(2)}`);
      await loadData();
      toast('success', 'تم اعتماد التقييم بنجاح');
    } catch {
      toast('error', 'فشل اعتماد التقييم');
    } finally {
      setLoading(false);
    }
  };

  const handleReopen = async () => {
    if (!selectedUserId) return;
    setLoading(true);
    try {
      await reopenEvaluation(selectedUserId, period);
      const reason = reopenReason.trim();
      void logAudit(actor, 'إلغاء اعتماد تقييم', `${selectedUser?.fullName || ''} | ${period === 'midyear' ? 'نصف سنوي' : 'نهائي'}${reason ? ` | السبب: ${reason}` : ''}`);
      setReopenOpen(false);
      setReopenReason('');
      await loadData();
      toast('success', 'تم إلغاء الاعتماد وأُعيد التقييم إلى مسودة، ويمكنك التعديل الآن');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'فشل إلغاء الاعتماد');
    } finally {
      setLoading(false);
    }
  };

  const totalScore = calculateTotal();
  const locked = evaluation?.status === 'approved';
  const selfByCriterion = new Map<string, number>((evaluation?.selfScores || []).map((x): [string, number] => [x.criterionId, x.rating]));
  const maxTotal = form ? form.criteria.reduce((sum, c) => sum + c.weight, 0) : 0;
  const selfPercent = (() => {
    if (!form || !maxTotal || selfByCriterion.size === 0) return null;
    const total = form.criteria.reduce((sum, c) => {
      const r = selfByCriterion.get(c.id);
      return sum + (r ? (r / 5) * c.weight : 0);
    }, 0);
    return (total / maxTotal) * 100;
  })();
  const managerPercent = maxTotal ? (totalScore / maxTotal) * 100 : 0;

  if (employees.length === 0) {
    return (
      <div className="card">
        <EmptyState
          icon={ClipboardList}
          title="لا يوجد موظفون للتقييم"
          message="أضف موظفين من قسم إدارة الكادر أولاً"
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {syncing && <div className="flex items-center justify-center gap-2 rounded-xl border border-primary-100 bg-primary-50 px-4 py-3 text-sm text-primary-700"><Save size={16} className="animate-pulse" />جاري مزامنة بيانات التقييم...</div>}
      {/* Employee + period selector */}
      <div className="card">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="min-w-0 flex-1 sm:min-w-[200px]">
            <label className="label-field">اختر الموظف</label>
            <select
              value={selectedUserId || ''}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="input-field"
            >
              {employees.map((emp) => (
                <option key={emp.id} value={emp.id}>
                  {emp.fullName} — {emp.civilId}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="label-field">فترة التقييم</label>
            <div className="flex gap-2">
              <button
                onClick={() => setPeriod('midyear')}
                className={`rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${
                  period === 'midyear' ? 'bg-gradient-to-l from-primary-600 to-primary-500 text-white shadow-card' : 'bg-white border border-neutral-200 text-neutral-600'
                }`}
              >
                نصف سنوي
              </button>
              <button
                onClick={() => setPeriod('final')}
                className={`rounded-xl px-4 py-2.5 text-sm font-bold transition-all ${
                  period === 'final' ? 'bg-gradient-to-l from-primary-600 to-primary-500 text-white shadow-card' : 'bg-white border border-neutral-200 text-neutral-600'
                }`}
              >
                سنوي
              </button>
            </div>
          </div>
        </div>

        {selectedUser && form && (
          <div className="mt-4 flex flex-wrap items-center gap-3 rounded-xl bg-neutral-50 p-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-secondary-100 font-bold text-secondary-700">
              {selectedUser.fullName.charAt(0)}
            </div>
            <div className="flex-1">
              <p className="font-bold text-neutral-800">{selectedUser.fullName}</p>
              <p className="text-xs text-neutral-500">
                {form.name} • {form.criteria.length} بند • {selectedUser.jobTitle || 'موظف'}
              </p>
            </div>
            <div className="text-left">
              <p className={`text-2xl font-bold ${getRatingColorFromTotal(totalScore)}`}>{totalScore.toFixed(2)}</p>
              <p className="text-xs text-neutral-500">{getRatingLabelFromTotal(totalScore)}</p>
            </div>
          </div>
        )}
      </div>

      {selectedUser && form && (
        <>
          {locked && (
            <div className="flex items-start gap-2 rounded-xl border border-success-300 bg-success-50 px-4 py-3 text-sm text-success-800">
              <Lock size={18} className="mt-0.5 flex-shrink-0" />
              <p>هذا التقييم <b>معتمد ومقفل</b>. لتعديل الدرجات أو الملاحظات اضغط «إلغاء الاعتماد» في أسفل الصفحة.</p>
            </div>
          )}
          {/* Criteria evaluation list */}
          <div className="space-y-4">
            {form.criteria.map((criterion, idx) => {
              const score = getScore(criterion.id);
              const criterionEvidence = evidence.filter((e) => e.criterionId === criterion.id);
              const weightedScore = score ? (score.rating / 5) * criterion.weight : 0;

              return (
                <AdminCriterionCard
                  key={criterion.id}
                  index={idx}
                  criterion={criterion}
                  score={score}
                  evidence={criterionEvidence}
                  onPreview={setPreviewEvidence}
                  onRate={(rating) => updateScore(criterion.id, rating, score?.notes || '')}
                  onNotesChange={(notes) => updateScore(criterion.id, score?.rating || 0, notes)}
                  weightedScore={weightedScore}
                  selfRating={selfByCriterion.get(criterion.id)}
                  locked={locked}
                />
              );
            })}
          </div>

          {/* General notes and actions */}
          <div className="card">
            <div className="mb-4 flex items-center gap-2">
              <MessageSquare className="text-secondary-600" size={20} />
              <h3 className="text-base font-bold text-neutral-800">التوصيات والملاحظات العامة</h3>
            </div>
            <textarea
              value={generalNotes}
              onChange={(e) => setGeneralNotes(e.target.value)}
              disabled={locked}
              className="input-field min-h-[100px] resize-y disabled:bg-neutral-100"
              placeholder="أضف توصيات وملاحظات عامة للموظف..."
            />

            {/* Summary */}
            <div className="mt-6 grid grid-cols-1 gap-3 sm:grid-cols-4">
              <div className="rounded-xl bg-neutral-50 p-4 text-center">
                <p className="text-xs text-neutral-500">الدرجة الكلية</p>
                <p className={`text-2xl font-bold ${getRatingColorFromTotal(totalScore)}`}>{totalScore.toFixed(2)}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-4 text-center">
                <p className="text-xs text-neutral-500">التقدير</p>
                <p className="text-lg font-bold text-neutral-800">{getRatingLabelFromTotal(totalScore)}</p>
              </div>
              <div className="rounded-xl bg-neutral-50 p-4 text-center">
                <p className="text-xs text-neutral-500">الحالة</p>
                <p className="text-lg font-bold text-neutral-800">
                  {evaluation?.status === 'approved' ? 'معتمد' : evaluation?.status === 'submitted' ? 'محفوظ' : 'مسودة'}
                </p>
              </div>
              <div className="rounded-xl bg-warning-50 p-4 text-center">
                <p className="text-xs text-neutral-500">التقييم الذاتي للمعلم</p>
                {selfPercent === null ? (
                  <p className="text-sm font-bold text-neutral-400">لم يقيّم نفسه بعد</p>
                ) : (
                  <>
                    <p className="text-lg font-bold text-neutral-800">{selfPercent.toFixed(1)}% • {getRatingLabel((selfPercent / 100) * 5)}</p>
                    <p className="text-xs text-neutral-500">
                      الفرق عن تقييمك: {selfPercent - managerPercent > 0 ? '+' : ''}{(selfPercent - managerPercent).toFixed(1)}%
                    </p>
                  </>
                )}
              </div>
            </div>

            {evaluation?.approvedAt && (
              <p className="mt-3 text-center text-xs text-neutral-400">
                اعتمد في: {formatDate(evaluation.approvedAt)}
              </p>
            )}

            <div className="mt-6 flex flex-wrap justify-start gap-2">
              {locked ? (
                <button onClick={() => setReopenOpen(true)} disabled={loading} className="btn-outline">
                  <Unlock size={18} />
                  إلغاء الاعتماد
                </button>
              ) : (
                <>
                  <button onClick={handleSaveDraft} disabled={loading} className="btn-secondary">
                    <Save size={18} />
                    {loading ? 'جاري الحفظ...' : 'حفظ التقييم'}
                  </button>
                  <button onClick={handleApprove} disabled={loading} className="btn-primary">
                    <CheckCircle2 size={18} />
                    اعتماد التقييم
                  </button>
                </>
              )}
            </div>
          </div>
        </>
      )}

      <Modal open={reopenOpen} onClose={() => setReopenOpen(false)} title="إلغاء اعتماد التقييم" size="sm">
        <div className="space-y-4">
          <p className="text-sm leading-relaxed text-neutral-700">
            سيُعاد تقييم <b>{selectedUser?.fullName}</b> ({period === 'midyear' ? 'النصف سنوي' : 'النهائي'}) إلى حالة <b>مسودة</b>،
            فتتمكن من تعديل الدرجات وإعادة الاعتماد. ولن تظهر النتيجة للمعلم حتى تعتمدها من جديد.
          </p>
          <div>
            <label className="label-field">سبب إلغاء الاعتماد (اختياري، يُسجَّل في السجل)</label>
            <textarea value={reopenReason} onChange={(e) => setReopenReason(e.target.value)} className="input-field min-h-[70px]" placeholder="مثال: اعتُمد بالخطأ قبل مراجعة الشواهد" />
          </div>
          <div className="flex gap-2">
            <button onClick={handleReopen} disabled={loading} className="btn-danger flex-1">{loading ? 'جاري التنفيذ...' : 'تأكيد إلغاء الاعتماد'}</button>
            <button onClick={() => setReopenOpen(false)} className="btn-outline flex-1">تراجع</button>
          </div>
        </div>
      </Modal>

      <FilePreviewModal evidence={previewEvidence} onClose={() => setPreviewEvidence(null)} />
    </div>
  );
}

interface AdminCriterionCardProps {
  index: number;
  criterion: { id: string; label: string; weight: number };
  score: Score | undefined;
  evidence: Evidence[];
  onPreview: (ev: Evidence) => void;
  onRate: (rating: number) => void;
  onNotesChange: (notes: string) => void;
  weightedScore: number;
  selfRating?: number;
  locked?: boolean;
}

function AdminCriterionCard({ index, criterion, score, evidence, onPreview, onRate, onNotesChange, weightedScore, selfRating, locked }: AdminCriterionCardProps) {
  const [showNotes, setShowNotes] = useState(!!score?.notes);
  const [localNotes, setLocalNotes] = useState(score?.notes || '');

  useEffect(() => {
    setLocalNotes(score?.notes || '');
    setShowNotes(!!score?.notes);
  }, [score?.notes]);

  return (
    <div className="card">
      {/* Header */}
      <div className="mb-3 flex items-start justify-between gap-3">
        <div className="flex items-start gap-3">
          <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-secondary-100 text-sm font-bold text-secondary-700">
            {index + 1}
          </span>
          <div>
            <h4 className="text-sm font-bold text-neutral-800">{criterion.label}</h4>
            <div className="mt-1 flex items-center gap-2">
              <span className="badge bg-primary-50 text-primary-700">الوزن: {criterion.weight}%</span>
              {score && (
                <span className="badge bg-secondary-50 text-secondary-700">
                  الدرجة: {weightedScore.toFixed(2)}%
                </span>
              )}
              {evidence.length > 0 && (
                <span className="badge bg-success-100 text-success-700">
                  {evidence.length} شاهد
                </span>
              )}
              {selfRating ? (
                <span className="badge bg-warning-50 text-warning-700">
                  ذاتي: {selfRating} — {RATING_LABELS[selfRating]}
                  {score?.rating ? (selfRating === score.rating ? ' • متطابق' : ` • ${selfRating > score.rating ? '+' : ''}${selfRating - score.rating} عن تقييمك`) : ''}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      {/* Evidence preview */}
      {evidence.length > 0 ? (
        <div className="mb-3 grid gap-2 sm:grid-cols-2">
          {evidence.map((ev) => (
            <EvidenceFileCard
              key={ev.id}
              evidence={ev}
              onPreview={() => onPreview(ev)}
              compact
            />
          ))}
        </div>
      ) : (
        <div className="mb-3 flex items-center gap-2 rounded-lg border border-dashed border-neutral-200 bg-neutral-50 px-3 py-2">
          <Lock size={14} className="text-neutral-400" />
          <p className="text-xs text-neutral-400">لم يرفع الموظف أي شاهد لهذا البند</p>
        </div>
      )}

      {/* Rating selector */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-bold text-neutral-600">التقييم:</span>
        {[1, 2, 3, 4, 5].map((rating) => (
          <button
            key={rating}
            onClick={() => onRate(rating)}
            disabled={locked}
            className={`flex items-center gap-1 rounded-lg border px-3 py-1.5 text-xs font-bold transition-all ${locked ? 'cursor-not-allowed opacity-60 ' : ''}${
              score?.rating === rating
                ? 'border-primary-500 bg-primary-50 text-primary-700 shadow-card'
                : 'border-neutral-200 bg-white text-neutral-500 hover:border-primary-300'
            }`}
          >
            <Star size={14} className={score?.rating === rating ? 'fill-primary-500 text-primary-500' : ''} />
            {rating} — {RATING_LABELS[rating]}
          </button>
        ))}
        <button
          onClick={() => setShowNotes(!showNotes)}
          className="btn-ghost text-xs"
        >
          <MessageSquare size={14} />
          {showNotes ? 'إخفاء الملاحظة' : 'إضافة ملاحظة'}
        </button>
      </div>

      {/* Notes */}
      {showNotes && (
        <div className="mt-3 animate-fade-in">
          <textarea
            value={localNotes}
            onChange={(e) => setLocalNotes(e.target.value)}
            onBlur={() => { if (!locked) onNotesChange(localNotes); }}
            disabled={locked}
            className="input-field min-h-[60px] resize-y text-sm disabled:bg-neutral-100"
            placeholder="ملاحظات حول هذا البند..."
          />
        </div>
      )}
    </div>
  );
}
