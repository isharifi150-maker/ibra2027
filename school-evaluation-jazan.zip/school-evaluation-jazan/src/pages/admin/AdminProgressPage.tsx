import { useCallback, useEffect, useMemo, useState } from 'react';
import { Activity, RefreshCw, Megaphone, Save, Trash2 } from 'lucide-react';
import { EVALUATION_FORMS } from '@/forms';
import { getAllUsers, getEvidenceByUser, getEvaluationsByUser, getAnnouncement, saveAnnouncement, logAudit } from '@/db';
import { useAuth } from '@/context/AuthContext';
import { ProgressBar } from '@/components/ui/ProgressBar';
import { toast } from '@/components/ui/Toast';
import { donutHtml } from '@/charts';
import type { User, Evaluation } from '@/types';

type Filter = 'all' | 'not_started' | 'incomplete' | 'pending';

interface Row {
  user: User;
  evidenceCount: number;
  progress: number;
  midyear?: Evaluation;
  final?: Evaluation;
}

const STATUS_LABEL: Record<Evaluation['status'], string> = {
  draft: 'مسودة',
  submitted: 'بانتظار الاعتماد',
  approved: 'معتمد',
};
const STATUS_CLASS: Record<Evaluation['status'], string> = {
  draft: 'bg-neutral-100 text-neutral-600',
  submitted: 'bg-warning-100 text-warning-700',
  approved: 'bg-success-100 text-success-700',
};

function StatusBadge({ evaluation }: { evaluation?: Evaluation }) {
  if (!evaluation) return <span className="badge bg-neutral-100 text-neutral-400">لم يُقيَّم</span>;
  return <span className={`badge ${STATUS_CLASS[evaluation.status]}`}>{STATUS_LABEL[evaluation.status]}</span>;
}

export function AdminProgressPage() {
  const { user: actor } = useAuth();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<Filter>('all');

  const [announcementText, setAnnouncementText] = useState('');
  const [deadline, setDeadline] = useState('');
  const [savingAnnouncement, setSavingAnnouncement] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const users = (await getAllUsers()).filter((u) => u.role === 'employee');
      const data = await Promise.all(users.map(async (u) => {
        const [evidence, evaluations] = await Promise.all([getEvidenceByUser(u.id), getEvaluationsByUser(u.id)]);
        const form = EVALUATION_FORMS[u.formType || 'teacher'];
        const uploaded = new Set(evidence.map((e) => e.criterionId)).size;
        const row: Row = {
          user: u,
          evidenceCount: evidence.length,
          progress: form.criteria.length ? (uploaded / form.criteria.length) * 100 : 0,
          midyear: evaluations.find((e) => e.period === 'midyear'),
          final: evaluations.find((e) => e.period === 'final'),
        };
        return row;
      }));
      setRows(data);
      const a = await getAnnouncement();
      setAnnouncementText(a?.text || '');
      setDeadline(a?.deadline || '');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر تحميل بيانات المتابعة');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const counts = useMemo(() => ({
    notStarted: rows.filter((r) => r.progress === 0).length,
    incomplete: rows.filter((r) => r.progress < 100).length,
    pending: rows.filter((r) => r.midyear?.status === 'submitted' || r.final?.status === 'submitted').length,
    complete: rows.filter((r) => r.progress >= 100).length,
  }), [rows]);

  const visible = rows.filter((r) => {
    if (filter === 'not_started') return r.progress === 0;
    if (filter === 'incomplete') return r.progress < 100;
    if (filter === 'pending') return r.midyear?.status === 'submitted' || r.final?.status === 'submitted';
    return true;
  });

  const handleSaveAnnouncement = async () => {
    setSavingAnnouncement(true);
    try {
      await saveAnnouncement(announcementText, deadline);
      void logAudit(actor, 'تحديث تنبيه المعلمين', announcementText.slice(0, 120));
      toast('success', 'تم حفظ التنبيه، وسيظهر للمعلمين في لوحتهم');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر حفظ التنبيه');
    } finally { setSavingAnnouncement(false); }
  };

  const handleClearAnnouncement = async () => {
    setSavingAnnouncement(true);
    try {
      await saveAnnouncement('', '');
      setAnnouncementText('');
      setDeadline('');
      void logAudit(actor, 'إزالة تنبيه المعلمين');
      toast('success', 'تمت إزالة التنبيه');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر إزالة التنبيه');
    } finally { setSavingAnnouncement(false); }
  };

  const chips: { id: Filter; label: string; count?: number }[] = [
    { id: 'all', label: 'الكل', count: rows.length },
    { id: 'not_started', label: 'لم يبدأ الرفع', count: counts.notStarted },
    { id: 'incomplete', label: 'شواهد ناقصة', count: counts.incomplete },
    { id: 'pending', label: 'بانتظار الاعتماد', count: counts.pending },
  ];

  return (
    <div className="space-y-6">
      {loading && (
        <div className="flex items-center justify-center gap-2 rounded-xl border border-primary-100 bg-primary-50 px-4 py-3 text-sm text-primary-700">
          <RefreshCw size={16} className="animate-spin" /> جاري تحميل بيانات المتابعة...
        </div>
      )}

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <div className="card"><p className="text-2xl font-bold text-neutral-800">{rows.length}</p><p className="text-xs text-neutral-500">إجمالي الموظفين</p></div>
        <div className="card"><p className="text-2xl font-bold text-success-600">{counts.complete}</p><p className="text-xs text-neutral-500">أكملوا جميع الشواهد</p></div>
        <div className="card"><p className="text-2xl font-bold text-error-600">{counts.notStarted}</p><p className="text-xs text-neutral-500">لم يبدأوا الرفع</p></div>
        <div className="card"><p className="text-2xl font-bold text-warning-600">{counts.pending}</p><p className="text-xs text-neutral-500">بانتظار اعتمادك</p></div>
      </div>

      {rows.length > 0 && (
        <div className="card">
          <h3 className="mb-3 text-base font-bold text-neutral-800">اكتمال رفع الشواهد</h3>
          <div dangerouslySetInnerHTML={{ __html: donutHtml([
            { label: 'أكمل جميع الشواهد', value: counts.complete, color: '#16a34a' },
            { label: 'شواهد ناقصة', value: rows.filter((r) => r.progress > 0 && r.progress < 100).length, color: '#f59e0b' },
            { label: 'لم يبدأ الرفع', value: counts.notStarted, color: '#dc2626' },
          ], `${Math.round(rows.reduce((s, r) => s + r.progress, 0) / rows.length)}%`) }} />
        </div>
      )}

      <div className="card">
        <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <Activity size={20} className="text-primary-600" />
            <h3 className="text-base font-bold text-neutral-800">حالة كل موظف</h3>
          </div>
          <button onClick={load} disabled={loading} className="btn-outline text-xs"><RefreshCw size={14} /> تحديث</button>
        </div>

        <div className="mb-4 flex flex-wrap gap-2">
          {chips.map((chip) => (
            <button
              key={chip.id}
              onClick={() => setFilter(chip.id)}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold ${filter === chip.id ? 'border-primary-600 bg-primary-600 text-white' : 'border-neutral-200 bg-white text-neutral-600'}`}
            >
              {chip.label} ({chip.count})
            </button>
          ))}
        </div>

        {visible.length === 0 ? (
          <p className="py-8 text-center text-sm text-neutral-500">لا توجد نتائج لهذا الفلتر</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-neutral-200 text-right text-xs text-neutral-500">
                  <th className="pb-3 pr-2 font-bold">الاسم</th>
                  <th className="pb-3 px-2 font-bold">الشواهد</th>
                  <th className="pb-3 px-2 font-bold">النصف سنوي</th>
                  <th className="pb-3 pl-2 font-bold">النهائي</th>
                </tr>
              </thead>
              <tbody>
                {visible.map((r) => (
                  <tr key={r.user.id} className="border-b border-neutral-100 last:border-0">
                    <td className="py-3 pr-2">
                      <p className="font-bold text-neutral-800">{r.user.fullName}</p>
                      <p className="text-xs text-neutral-500">{r.user.jobTitle || (r.user.formType ? EVALUATION_FORMS[r.user.formType].shortName : '')}</p>
                    </td>
                    <td className="min-w-[120px] px-2">
                      <ProgressBar value={r.progress} size="sm" showValue={false} />
                      <p className="mt-1 text-xs text-neutral-500">{r.progress.toFixed(0)}% • {r.evidenceCount} ملف</p>
                    </td>
                    <td className="px-2"><StatusBadge evaluation={r.midyear} /></td>
                    <td className="pl-2"><StatusBadge evaluation={r.final} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <div className="card space-y-3">
        <div className="flex items-center gap-2">
          <Megaphone size={20} className="text-primary-600" />
          <h3 className="text-base font-bold text-neutral-800">تنبيه للمعلمين</h3>
        </div>
        <p className="text-xs text-neutral-500">يظهر في أعلى لوحة كل معلم وصفحة الشواهد، مع عدّاد الأيام المتبقية إن حددت موعداً.</p>
        <div>
          <label className="label-field">نص التنبيه</label>
          <textarea
            value={announcementText}
            onChange={(e) => setAnnouncementText(e.target.value)}
            className="input-field min-h-[90px]"
            placeholder="مثال: يرجى استكمال رفع الشواهد قبل نهاية الفصل الدراسي"
          />
        </div>
        <div>
          <label className="label-field">آخر موعد لرفع الشواهد (اختياري)</label>
          <input type="date" value={deadline} onChange={(e) => setDeadline(e.target.value)} className="input-field" />
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={handleSaveAnnouncement} disabled={savingAnnouncement} className="btn-primary">
            <Save size={16} /> {savingAnnouncement ? 'جاري الحفظ...' : 'حفظ التنبيه'}
          </button>
          <button onClick={handleClearAnnouncement} disabled={savingAnnouncement} className="btn-outline">
            <Trash2 size={16} /> إزالة التنبيه
          </button>
        </div>
      </div>
    </div>
  );
}
