import { useCallback, useEffect, useMemo, useState } from 'react';
import { BarChart3, RefreshCw, Printer, TrendingUp, TrendingDown } from 'lucide-react';
import { EVALUATION_FORMS, getRatingLabel } from '@/forms';
import { getAllUsers, getEvaluationsByUser } from '@/db';
import { toast } from '@/components/ui/Toast';
import { DEPARTMENT_NAME, PERIOD_LABELS, PRINCIPAL_NAME, escapeHtml, type EvalPeriod } from '@/school';
import type { User, Evaluation } from '@/types';

interface Loaded { user: User; evals: Evaluation[] }
interface CriterionStat { label: string; avgRating: number; avgPercent: number; count: number }

function percentOf(user: User, ev: Evaluation): number {
  const form = EVALUATION_FORMS[user.formType || 'teacher'];
  const maxTotal = form.criteria.reduce((sum, c) => sum + c.weight, 0);
  let total = 0;
  form.criteria.forEach((c) => {
    const sc = ev.scores?.find((x) => x.criterionId === c.id);
    if (sc) total += (sc.rating / 5) * c.weight;
  });
  return maxTotal ? (total / maxTotal) * 100 : 0;
}

const RATING_ORDER = ['ممتاز', 'جيد جداً', 'جيد', 'مقبول', 'ضعيف'];

export function AdminReportPage() {
  const [data, setData] = useState<Loaded[]>([]);
  const [period, setPeriod] = useState<EvalPeriod>('final');
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const users = (await getAllUsers()).filter((u) => u.role === 'employee');
      setData(await Promise.all(users.map(async (u) => ({ user: u, evals: await getEvaluationsByUser(u.id) }))));
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر تحميل بيانات التقرير');
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { load(); }, [load]);

  const report = useMemo(() => {
    const evaluate = (per: EvalPeriod) => {
      const people: { user: User; percent: number }[] = [];
      const byCriterion = new Map<string, { sum: number; count: number }>();
      data.forEach(({ user, evals }) => {
        const ev = evals.find((e) => e.period === per);
        if (!ev || !ev.scores?.length) return;
        people.push({ user, percent: percentOf(user, ev) });
        const form = EVALUATION_FORMS[user.formType || 'teacher'];
        ev.scores.forEach((sc) => {
          const criterion = form.criteria.find((c) => c.id === sc.criterionId);
          if (!criterion || !sc.rating) return;
          const cur = byCriterion.get(criterion.label) || { sum: 0, count: 0 };
          cur.sum += sc.rating; cur.count += 1;
          byCriterion.set(criterion.label, cur);
        });
      });
      const avg = people.length ? people.reduce((s, p) => s + p.percent, 0) / people.length : 0;
      const criteria: CriterionStat[] = [...byCriterion.entries()].map(([label, v]) => ({
        label, count: v.count, avgRating: v.sum / v.count, avgPercent: (v.sum / v.count / 5) * 100,
      })).sort((a, b) => a.avgRating - b.avgRating);
      const distribution = RATING_ORDER.map((label) => ({
        label,
        count: people.filter((p) => getRatingLabel((p.percent / 100) * 5) === label).length,
      }));
      const sorted = [...people].sort((a, b) => b.percent - a.percent);
      return { people, avg, criteria, distribution, top: sorted[0], bottom: sorted[sorted.length - 1] };
    };
    return { current: evaluate(period), midyear: evaluate('midyear'), final: evaluate('final') };
  }, [data, period]);

  const { current } = report;
  const weakest = current.criteria.slice(0, 5);
  const strongest = [...current.criteria].reverse().slice(0, 5);

  const handlePrint = () => {
    const win = window.open('', '_blank', 'width=900,height=1100');
    if (!win) { toast('error', 'تعذر فتح نافذة الطباعة. يرجى السماح بالنوافذ المنبثقة'); return; }
    const rows = current.criteria.map((c, i) => `<tr><td class="c">${i + 1}</td><td>${escapeHtml(c.label)}</td><td class="c">${c.avgRating.toFixed(2)}</td><td class="c">${c.avgPercent.toFixed(1)}%</td><td class="c">${c.count}</td></tr>`).join('');
    const dist = current.distribution.map((d) => `<tr><td>${d.label}</td><td class="c">${d.count}</td></tr>`).join('');
    win.document.write(`<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8" /><title>تقرير المدرسة - ${PERIOD_LABELS[period]}</title>
<style>@page{size:A4;margin:12mm}*{box-sizing:border-box}body{font-family:'Segoe UI',Tahoma,Arial,sans-serif;font-size:12px;color:#111}
.header{display:flex;justify-content:space-between;border-bottom:2px solid #111;padding-bottom:8px;margin-bottom:12px;font-weight:bold;line-height:1.8}
h1{text-align:center;font-size:17px;margin:8px 0 12px}h2{font-size:14px;margin:16px 0 6px}
table{width:100%;border-collapse:collapse;margin-bottom:10px}th,td{border:1px solid #444;padding:5px 7px}th{background:#ddd}td.c,th.c{text-align:center}
.kpi{display:flex;gap:10px;margin-bottom:10px}.kpi div{flex:1;border:1px solid #444;padding:8px;text-align:center}.kpi b{display:block;font-size:16px}
.sign{margin-top:30px;text-align:left}tr{page-break-inside:avoid}</style></head><body>
<div class="header"><div>المملكة العربية السعودية<br/>وزارة التعليم<br/>${DEPARTMENT_NAME}</div><div>التاريخ: ......../......../........ هـ</div></div>
<h1>تقرير أداء المدرسة - ${PERIOD_LABELS[period]}</h1>
<div class="kpi"><div><b>${current.people.length}</b>عدد المقيَّمين</div><div><b>${current.avg.toFixed(1)}%</b>متوسط الأداء العام</div><div><b>${report.midyear.avg.toFixed(1)}% / ${report.final.avg.toFixed(1)}%</b>نصفي / نهائي</div></div>
<h2>توزيع التقديرات</h2><table><thead><tr><th>التقدير</th><th class="c">عدد المعلمين</th></tr></thead><tbody>${dist}</tbody></table>
<h2>متوسط الأداء حسب البند (من الأضعف إلى الأقوى)</h2><table><thead><tr><th class="c">م</th><th>البند</th><th class="c">المتوسط من 5</th><th class="c">النسبة</th><th class="c">عدد التقييمات</th></tr></thead><tbody>${rows}</tbody></table>
<div class="sign">مدير المدرسة: ${PRINCIPAL_NAME}<br/><br/>التوقيع: ..............................</div>
<script>window.onload=function(){setTimeout(function(){window.focus();window.print();},300)}</script></body></html>`);
    win.document.close();
  };

  return (
    <div className="space-y-6">
      {loading && (
        <div className="flex items-center justify-center gap-2 rounded-xl border border-primary-100 bg-primary-50 px-4 py-3 text-sm text-primary-700">
          <RefreshCw size={16} className="animate-spin" /> جاري تحميل بيانات التقرير...
        </div>
      )}

      <div className="card flex flex-wrap items-end justify-between gap-3">
        <div>
          <label className="label-field">فترة التقرير</label>
          <div className="flex gap-2">
            {(['midyear', 'final'] as EvalPeriod[]).map((p) => (
              <button key={p} onClick={() => setPeriod(p)} className={period === p ? 'btn-primary' : 'btn-outline'}>{PERIOD_LABELS[p]}</button>
            ))}
          </div>
        </div>
        <button onClick={handlePrint} disabled={current.people.length === 0} className="btn-outline"><Printer size={16} /> طباعة التقرير</button>
      </div>

      {current.people.length === 0 && !loading ? (
        <div className="card py-10 text-center text-sm text-neutral-500">لا توجد تقييمات مسجلة لـ{PERIOD_LABELS[period]} بعد</div>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <div className="card"><p className="text-2xl font-bold text-neutral-800">{current.people.length}</p><p className="text-xs text-neutral-500">عدد المقيَّمين</p></div>
            <div className="card"><p className="text-2xl font-bold text-primary-600">{current.avg.toFixed(1)}%</p><p className="text-xs text-neutral-500">متوسط الأداء العام</p></div>
            <div className="card"><p className="text-lg font-bold text-neutral-800">{report.midyear.avg.toFixed(1)}% ← {report.final.avg.toFixed(1)}%</p><p className="text-xs text-neutral-500">النصفي ← النهائي</p></div>
            <div className="card"><p className="text-sm font-bold text-neutral-800">{current.top?.user.fullName}</p><p className="text-xs text-neutral-500">الأعلى أداءً ({current.top?.percent.toFixed(1)}%)</p></div>
          </div>

          <div className="card">
            <h3 className="mb-3 flex items-center gap-2 text-base font-bold text-neutral-800"><BarChart3 size={18} className="text-primary-600" /> توزيع التقديرات</h3>
            <div className="space-y-2">
              {current.distribution.map((d) => (
                <div key={d.label} className="flex items-center gap-3 text-sm">
                  <span className="w-20 text-neutral-600">{d.label}</span>
                  <div className="h-3 flex-1 overflow-hidden rounded-full bg-neutral-100">
                    <div className="h-full rounded-full bg-primary-500" style={{ width: `${current.people.length ? (d.count / current.people.length) * 100 : 0}%` }} />
                  </div>
                  <span className="w-8 text-left font-bold text-neutral-700">{d.count}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            <div className="card">
              <h3 className="mb-3 flex items-center gap-2 text-base font-bold text-success-700"><TrendingUp size={18} /> أقوى البنود</h3>
              <ul className="space-y-2 text-sm">
                {strongest.map((c) => <li key={c.label} className="flex justify-between gap-3"><span>{c.label}</span><span className="font-bold">{c.avgRating.toFixed(2)}</span></li>)}
              </ul>
            </div>
            <div className="card">
              <h3 className="mb-3 flex items-center gap-2 text-base font-bold text-error-700"><TrendingDown size={18} /> أضعف البنود (تحتاج تطويراً)</h3>
              <ul className="space-y-2 text-sm">
                {weakest.map((c) => <li key={c.label} className="flex justify-between gap-3"><span>{c.label}</span><span className="font-bold">{c.avgRating.toFixed(2)}</span></li>)}
              </ul>
            </div>
          </div>

          <div className="card">
            <h3 className="mb-3 text-base font-bold text-neutral-800">متوسط الأداء حسب البند</h3>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-neutral-200 text-right text-xs text-neutral-500">
                    <th className="pb-2 pr-2 font-bold">البند</th>
                    <th className="pb-2 px-2 font-bold">المتوسط من 5</th>
                    <th className="pb-2 px-2 font-bold">النسبة</th>
                    <th className="pb-2 pl-2 font-bold">العدد</th>
                  </tr>
                </thead>
                <tbody>
                  {current.criteria.map((c) => (
                    <tr key={c.label} className="border-b border-neutral-100 last:border-0">
                      <td className="py-2 pr-2">{c.label}</td>
                      <td className="px-2 font-bold">{c.avgRating.toFixed(2)}</td>
                      <td className="px-2">{c.avgPercent.toFixed(1)}%</td>
                      <td className="pl-2 text-neutral-500">{c.count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
