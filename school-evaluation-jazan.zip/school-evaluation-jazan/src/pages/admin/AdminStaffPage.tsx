import { useEffect, useState, useCallback } from 'react';
import {
  UserPlus, Search, Edit2, Trash2, KeyRound, RefreshCw, Eye, EyeOff,
  Users, GraduationCap, FlaskConical, Trophy, HeartPulse, Compass, X, Check,
  FileSpreadsheet, Printer,
  type LucideIcon
} from 'lucide-react';
import { EVALUATION_FORMS, getRatingLabel } from '@/forms';
import { getAllUsers, saveUser, deleteUser, getUserByCivilId, getScoresByPeriod, getEvaluationsByUser, logAudit } from '@/db';
import { useAuth } from '@/context/AuthContext';
import { buildXlsx, downloadBytes, XS, XLSX_MIME, type Cell } from '@/xlsx';
import { DEPARTMENT_NAME, PERIOD_LABELS, PRINCIPAL_NAME, escapeHtml, todayStamp, type EvalPeriod } from '@/school';
import { Modal } from '@/components/ui/Modal';
import { ConfirmDialog } from '@/components/ui/FilePreview';
import { toast } from '@/components/ui/Toast';
import { generateId, generatePassword, formatDateShort } from '@/utils';
import type { User, FormType, Evaluation } from '@/types';

const formIconMap: Record<string, LucideIcon> = {
  GraduationCap, Trophy, HeartPulse, FlaskConical, Compass,
};

const FORM_STYLE = `
  @page { size: A4; margin: 12mm; }
  * { box-sizing: border-box; }
  body { font-family: 'Segoe UI', Tahoma, 'Noto Naskh Arabic', Arial, sans-serif; color: #111; font-size: 12px; margin: 0; }
  .page { page-break-after: always; }
  .page:last-child { page-break-after: auto; }
  .header { display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 2px solid #111; padding-bottom: 8px; margin-bottom: 12px; }
  .header div { line-height: 1.8; font-weight: bold; font-size: 12px; }
  .header .center { text-align: center; }
  h1 { text-align: center; font-size: 17px; margin: 8px 0 12px; }
  .info { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
  .info td { border: 1px solid #444; padding: 6px 8px; }
  .info td.l { background: #eee; font-weight: bold; width: 18%; }
  table.crit { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
  table.crit th, table.crit td { border: 1px solid #444; padding: 5px 7px; }
  table.crit th { background: #ddd; }
  td.c, th.c { text-align: center; }
  tr.total td { background: #f1f1f1; font-weight: bold; }
  .sign { display: flex; gap: 20px; margin-top: 26px; }
  .sign .box { flex: 1; border: 1px solid #444; padding: 10px; min-height: 110px; }
  .sign .box b { display: block; margin-bottom: 8px; }
  .line { margin-top: 22px; }
  .note { margin-top: 10px; font-size: 10px; color: #444; }
  tr { page-break-inside: avoid; }
`;

const buildFormSection = (emp: User, ratings: Record<string, number>, period: EvalPeriod): string => {
  const form = emp.formType ? EVALUATION_FORMS[emp.formType] : EVALUATION_FORMS.teacher;
  const hasRatings = Object.keys(ratings).length > 0;
  let total = 0;
  const rows = form.criteria.map((c, i) => {
    const rating = ratings[c.id];
    if (rating) total += (rating / 5) * c.weight;
    return `<tr>
      <td class="c">${i + 1}</td>
      <td>${escapeHtml(c.label)}</td>
      <td class="c">${c.weight}</td>
      <td class="c">${rating ? rating : ''}</td>
      <td class="c">${rating ? ((rating / 5) * c.weight).toFixed(1) : ''}</td>
    </tr>`;
  }).join('');
  const maxTotal = form.criteria.reduce((sum, c) => sum + c.weight, 0);
  const finalLabel = hasRatings ? getRatingLabel((total / maxTotal) * 5) : '';

  return `<div class="page">
  <div class="header">
    <div>المملكة العربية السعودية<br/>وزارة التعليم<br/>${DEPARTMENT_NAME}</div>
    <div class="center">بسم الله الرحمن الرحيم</div>
    <div>التاريخ: ......../......../........ هـ</div>
  </div>
  <h1>استمارة تقييم الأداء الوظيفي - ${PERIOD_LABELS[period]}</h1>
  <table class="info">
    <tr><td class="l">الاسم</td><td>${escapeHtml(emp.fullName)}</td><td class="l">السجل المدني</td><td>${escapeHtml(emp.civilId)}</td></tr>
    <tr><td class="l">المسمى الوظيفي</td><td>${escapeHtml(emp.jobTitle || form.shortName)}</td><td class="l">نموذج التقييم</td><td>${escapeHtml(form.name)}</td></tr>
  </table>
  <table class="crit">
    <thead>
      <tr><th class="c" style="width:6%">م</th><th>معيار الأداء</th><th class="c" style="width:12%">الوزن</th><th class="c" style="width:12%">التقدير (1-5)</th><th class="c" style="width:12%">الدرجة</th></tr>
    </thead>
    <tbody>
      ${rows}
      <tr class="total">
        <td colspan="2">المجموع النهائي</td>
        <td class="c">${maxTotal}</td>
        <td class="c">${finalLabel}</td>
        <td class="c">${hasRatings ? total.toFixed(1) : ''}</td>
      </tr>
    </tbody>
  </table>
  <div class="sign">
    <div class="box"><b>المعلم / الموظف</b>الاسم: ${escapeHtml(emp.fullName)}<div class="line">التوقيع: ..............................</div><div class="line">التاريخ: ..............................</div></div>
    <div class="box"><b>مدير المدرسة</b>الاسم: ${PRINCIPAL_NAME}<div class="line">التوقيع: ..............................</div><div class="line">الاعتماد / الختم: ..............................</div></div>
  </div>
  <p class="note">طُبعت هذه الاستمارة من نظام تقييم الأداء المدرسي.</p>
</div>`;
};

const wrapPrintHtml = (title: string, sections: string[]): string => `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8" />
<title>${escapeHtml(title)}</title>
<style>${FORM_STYLE}</style>
</head>
<body>
  ${sections.join('\n')}
  <script>window.onload = function () { setTimeout(function () { window.focus(); window.print(); }, 300); };</script>
</body>
</html>`;

interface StaffFormData {
  fullName: string;
  civilId: string;
  jobTitle: string;
  formType: FormType;
  password: string;
  mustChangePassword: boolean;
}

export function AdminStaffPage() {
  const { user: actor } = useAuth();
  const [employees, setEmployees] = useState<User[]>([]);
  const [search, setSearch] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<User | null>(null);
  const [resetTarget, setResetTarget] = useState<User | null>(null);
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [syncing, setSyncing] = useState(true);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [printingAll, setPrintingAll] = useState(false);

  // Form state
  const [formData, setFormData] = useState<StaffFormData>({
    fullName: '', civilId: '', jobTitle: '', formType: 'teacher', password: '', mustChangePassword: true,
  });
  const [showFormPassword, setShowFormPassword] = useState(false);

  const loadStaff = useCallback(async () => {
    setSyncing(true);
    try {
      const users = await getAllUsers();
      setEmployees(users.filter((u) => u.role === 'employee'));
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر مزامنة بيانات الكادر');
    } finally { setSyncing(false); }
  }, []);

  useEffect(() => { loadStaff(); }, [loadStaff]);

  const filtered = employees.filter((e) =>
    e.fullName.includes(search) || e.civilId.includes(search) || (e.jobTitle || '').includes(search)
  );

  const handleExportExcel = async () => {
    if (filtered.length === 0) {
      toast('error', 'لا توجد بيانات لتصديرها');
      return;
    }
    setExporting(true);
    try {
      // Scores live inside each evaluation (evaluations.scores), so fetch evaluations per employee.
      const evalsByUser = new Map<string, Evaluation[]>();
      await Promise.all(filtered.map(async (e) => {
        evalsByUser.set(e.id, await getEvaluationsByUser(e.id));
      }));

      const periods: EvalPeriod[] = ['midyear', 'final'];
      const calc = (emp: User, ev?: Evaluation) => {
        const form = EVALUATION_FORMS[emp.formType || 'teacher'];
        const maxTotal = form.criteria.reduce((sum, c) => sum + c.weight, 0);
        let total = 0;
        form.criteria.forEach((c) => {
          const sc = ev?.scores?.find((x) => x.criterionId === c.id);
          if (sc) total += (sc.rating / 5) * c.weight;
        });
        const percent = maxTotal ? (total / maxTotal) * 100 : 0;
        return { form, maxTotal, total, percent, label: ev?.scores?.length ? getRatingLabel((percent / 100) * 5) : '' };
      };
      const num = (v: number, digits = 2) => Number(v.toFixed(digits));
      const H = (v: string): Cell => ({ v, s: XS.header });
      const B = (v: string | number | null): Cell => ({ v, s: XS.body });

      const summary: Cell[][] = [
        [{ v: 'المملكة العربية السعودية - وزارة التعليم', s: XS.title }],
        [{ v: DEPARTMENT_NAME, s: XS.title }],
        [{ v: `مدير المدرسة المعتمد: ${PRINCIPAL_NAME}`, s: XS.normal }],
        [],
        ['م', 'الاسم', 'السجل المدني', 'المسمى الوظيفي', 'نموذج التقييم',
          'درجة النصف سنوي', 'النسبة % (نصف سنوي)', 'التقدير (نصف سنوي)',
          'درجة النهائي', 'النسبة % (نهائي)', 'التقدير (نهائي)'].map(H),
      ];
      filtered.forEach((emp, i) => {
        const evs = evalsByUser.get(emp.id) || [];
        const row: Cell[] = [B(i + 1), B(emp.fullName), B(emp.civilId), B(emp.jobTitle || ''),
          B(emp.formType ? EVALUATION_FORMS[emp.formType].shortName : '')];
        periods.forEach((per) => {
          const ev = evs.find((x) => x.period === per);
          if (ev?.scores?.length) {
            const r = calc(emp, ev);
            row.push(B(num(r.total)), B(num(r.percent, 1)), B(r.label));
          } else {
            row.push(B(''), B(''), B(''));
          }
        });
        summary.push(row);
      });

      const details: Cell[][] = [
        ['الاسم', 'السجل المدني', 'الفترة', 'م', 'البند', 'الوزن', 'التقدير (من 5)', 'الدرجة', 'ملاحظات'].map(H),
      ];
      filtered.forEach((emp) => {
        const evs = evalsByUser.get(emp.id) || [];
        periods.forEach((per) => {
          const ev = evs.find((x) => x.period === per);
          if (!ev?.scores?.length) return;
          const r = calc(emp, ev);
          r.form.criteria.forEach((c, idx) => {
            const sc = ev.scores?.find((x) => x.criterionId === c.id);
            details.push([B(emp.fullName), B(emp.civilId), B(PERIOD_LABELS[per]), B(idx + 1), B(c.label), B(c.weight),
              B(sc ? sc.rating : ''), B(sc ? num((sc.rating / 5) * c.weight) : ''), B(sc?.notes || '')]);
          });
          details.push([B(emp.fullName), B(emp.civilId), B(PERIOD_LABELS[per]), B(''), { v: 'المجموع', s: XS.header },
            B(r.maxTotal), B(r.label), B(`${num(r.total)} (${num(r.percent, 1)}%)`), B('')]);
        });
      });

      const bytes = buildXlsx([
        { name: 'الملخص', rows: summary, widths: [6, 28, 16, 22, 22, 14, 14, 14, 14, 14, 14] },
        { name: 'تفاصيل البنود', rows: details, widths: [28, 16, 20, 6, 48, 10, 14, 12, 36] },
      ]);
      downloadBytes(`تقييمات-المعلمين-${todayStamp()}.xlsx`, bytes, XLSX_MIME);
      void logAudit(actor, 'تصدير إكسل', `${filtered.length} موظف`);
      toast('success', 'تم تصدير ملف إكسل بنجاح');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر تصدير البيانات');
    } finally { setExporting(false); }
  };

  const handlePrintEmployee = async (emp: User, period: EvalPeriod) => {
    // Open synchronously to avoid popup blockers
    const win = window.open('', '_blank', 'width=900,height=1100');
    if (!win) {
      toast('error', 'تعذر فتح نافذة الطباعة. يرجى السماح بالنوافذ المنبثقة');
      return;
    }
    win.document.write('<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8" /></head><body style="font-family:sans-serif;text-align:center;padding:40px">جاري تجهيز الاستمارة...</body></html>');
    const ratings: Record<string, number> = {};
    try {
      const scores = await getScoresByPeriod(emp.id, period);
      scores.forEach((sc) => { ratings[sc.criterionId] = sc.rating; });
      if (scores.length === 0) toast('info', `لا توجد درجات مسجلة لـ${PERIOD_LABELS[period]} - ستُطبع الاستمارة فارغة`);
    } catch {
      // Print a blank form if scores cannot be loaded
    }
    win.document.open();
    win.document.write(wrapPrintHtml(`استمارة تقييم الأداء الوظيفي (${PERIOD_LABELS[period]}) - ${emp.fullName}`, [buildFormSection(emp, ratings, period)]));
    win.document.close();
  };

  const handlePrintAll = async (period: EvalPeriod) => {
    if (filtered.length === 0) {
      toast('error', 'لا يوجد موظفون للطباعة');
      return;
    }
    const win = window.open('', '_blank', 'width=900,height=1100');
    if (!win) {
      toast('error', 'تعذر فتح نافذة الطباعة. يرجى السماح بالنوافذ المنبثقة');
      return;
    }
    win.document.write('<!DOCTYPE html><html lang="ar" dir="rtl"><head><meta charset="UTF-8" /></head><body style="font-family:sans-serif;text-align:center;padding:40px">جاري تجهيز الاستمارات...</body></html>');
    setPrintingAll(true);
    try {
      const sections = await Promise.all(filtered.map(async (emp) => {
        const ratings: Record<string, number> = {};
        try {
          const scores = await getScoresByPeriod(emp.id, period);
          scores.forEach((sc) => { ratings[sc.criterionId] = sc.rating; });
        } catch {
          // blank form for this employee
        }
        return buildFormSection(emp, ratings, period);
      }));
      win.document.open();
      win.document.write(wrapPrintHtml(`استمارات ${PERIOD_LABELS[period]} - ${filtered.length} موظف`, sections));
      win.document.close();
      void logAudit(actor, 'طباعة جماعية', `${PERIOD_LABELS[period]} - ${filtered.length} موظف`);
    } catch (error) {
      win.close();
      toast('error', error instanceof Error ? error.message : 'تعذر تجهيز الاستمارات');
    } finally { setPrintingAll(false); }
  };

  const openAddForm = () => {
    setEditingUser(null);
    setFormData({ fullName: '', civilId: '', jobTitle: '', formType: 'teacher', password: '', mustChangePassword: true });
    setShowForm(true);
  };

  const openEditForm = (user: User) => {
    setEditingUser(user);
    setFormData({
      fullName: user.fullName,
      civilId: user.civilId,
      jobTitle: user.jobTitle || '',
      formType: user.formType || 'teacher',
      password: user.password,
      mustChangePassword: user.mustChangePassword,
    });
    setShowForm(true);
  };

  const handleSave = async () => {
    setSaving(true);
    try {
    if (!formData.fullName.trim() || !formData.civilId.trim() || !formData.password.trim()) {
      toast('error', 'يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    // Check for duplicate civilId
    const existing = await getUserByCivilId(formData.civilId.trim());
    if (existing && existing.id !== editingUser?.id) {
      toast('error', 'رقم السجل المدني مستخدم بالفعل');
      return;
    }

    if (editingUser) {
      const updated: User = {
        ...editingUser,
        fullName: formData.fullName.trim(),
        civilId: formData.civilId.trim(),
        jobTitle: formData.jobTitle.trim(),
        formType: formData.formType,
        password: formData.password,
        mustChangePassword: formData.mustChangePassword,
      };
      await saveUser(updated);
      void logAudit(actor, 'تعديل بيانات موظف', updated.fullName);
      toast('success', 'تم تحديث بيانات الموظف');
    } else {
      const newUser: User = {
        id: generateId(),
        fullName: formData.fullName.trim(),
        civilId: formData.civilId.trim(),
        jobTitle: formData.jobTitle.trim(),
        role: 'employee',
        formType: formData.formType,
        password: formData.password,
        mustChangePassword: formData.mustChangePassword,
        createdAt: Date.now(),
      };
      await saveUser(newUser);
      void logAudit(actor, 'إضافة موظف', newUser.fullName);
      toast('success', 'تم إضافة الموظف بنجاح');
    }

    setShowForm(false);
    await loadStaff();
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'فشل حفظ البيانات في Supabase');
    } finally { setSaving(false); }
  };

  const handleDelete = async () => {
    if (!deleteTarget) return;
    setSaving(true);
    try {
      await deleteUser(deleteTarget.id);
      void logAudit(actor, 'حذف موظف', deleteTarget.fullName);
      toast('success', 'تم حذف الموظف وكل بياناته من السحابة');
      setDeleteTarget(null);
      await loadStaff();
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'فشل حذف الموظف من Supabase');
    } finally { setSaving(false); }
  };

  const handleResetPassword = async (newPassword: string) => {
    if (!resetTarget) return;
    setSaving(true);
    try {
      const updated = { ...resetTarget, password: newPassword, mustChangePassword: true };
      await saveUser(updated);
      void logAudit(actor, 'إعادة ضبط كلمة مرور', resetTarget.fullName);
      toast('success', `تم إعادة ضبط كلمة المرور. كلمة المرور الجديدة: ${newPassword}`);
      setResetTarget(null);
      await loadStaff();
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'فشل تحديث كلمة المرور في Supabase');
    } finally { setSaving(false); }
  };

  const [resetPasswordValue, setResetPasswordValue] = useState('');

  const openResetDialog = (user: User) => {
    setResetTarget(user);
    setResetPasswordValue(generatePassword());
  };

  return (
    <div className="space-y-6">
      {syncing && <div className="flex items-center justify-center gap-2 rounded-xl border border-primary-100 bg-primary-50 px-4 py-3 text-sm text-primary-700"><RefreshCw size={16} className="animate-spin" />جاري المزامنة مع Supabase...</div>}
      {/* Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="relative w-full min-w-0 flex-1 sm:min-w-[200px] sm:max-w-md">
          <Search size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="input-field pr-10"
            placeholder="بحث بالاسم أو رقم السجل المدني..."
          />
        </div>
        <div className="flex w-full flex-wrap gap-2 sm:w-auto">
          <button onClick={handleExportExcel} disabled={exporting} className="btn-outline w-full sm:w-auto">
            <FileSpreadsheet size={18} />
            {exporting ? 'جاري التصدير...' : 'تصدير إكسل'}
          </button>
          <button onClick={() => handlePrintAll('midyear')} disabled={printingAll} className="btn-outline w-full sm:w-auto">
            <Printer size={18} />
            طباعة الكل (نصفي)
          </button>
          <button onClick={() => handlePrintAll('final')} disabled={printingAll} className="btn-outline w-full sm:w-auto">
            <Printer size={18} />
            طباعة الكل (نهائي)
          </button>
          <button onClick={openAddForm} className="btn-primary w-full sm:w-auto">
            <UserPlus size={18} />
            إضافة موظف
          </button>
        </div>
      </div>

      {/* Staff list */}
      <div className="card">
        {filtered.length === 0 ? (
          <div className="flex flex-col items-center py-12 text-center">
            <Users size={32} className="mb-3 text-neutral-400" />
            <p className="text-sm font-bold text-neutral-700">
              {employees.length === 0 ? 'لا يوجد موظفون بعد' : 'لا توجد نتائج مطابقة'}
            </p>
            {employees.length === 0 && (
              <button onClick={openAddForm} className="btn-primary mt-4">
                <UserPlus size={16} /> إضافة أول موظف
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-neutral-200 text-right text-xs text-neutral-500">
                  <th className="pb-3 pr-2 font-bold">الاسم</th>
                  <th className="hidden pb-3 px-2 font-bold sm:table-cell">رقم السجل</th>
                  <th className="hidden pb-3 px-2 font-bold md:table-cell">النموذج</th>
                  <th className="hidden pb-3 px-2 font-bold lg:table-cell">كلمة المرور</th>
                  <th className="hidden pb-3 px-2 font-bold xl:table-cell">أضيف في</th>
                  <th className="pb-3 pl-2 font-bold">إجراءات</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((emp) => {
                  const form = emp.formType ? EVALUATION_FORMS[emp.formType] : null;
                  const FormIcon = form ? formIconMap[form.icon] : null;
                  const showPwd = showPasswords[emp.id];
                  return (
                    <tr key={emp.id} className="border-b border-neutral-100 last:border-0 hover:bg-neutral-50">
                      <td className="py-3 pr-2">
                        <div className="flex items-center gap-2">
                          <div className="flex h-9 w-9 items-center justify-center rounded-full bg-secondary-100 text-sm font-bold text-secondary-700">
                            {emp.fullName.charAt(0)}
                          </div>
                          <div>
                            <p className="font-bold text-neutral-800">{emp.fullName}</p>
                            {emp.jobTitle && <p className="text-xs text-neutral-500">{emp.jobTitle}</p>}
                          </div>
                        </div>
                      </td>
                      <td className="hidden px-2 font-mono text-xs text-neutral-600 sm:table-cell">{emp.civilId}</td>
                      <td className="hidden px-2 md:table-cell">
                        {form && FormIcon ? (
                          <span className="inline-flex items-center gap-1.5 rounded-lg bg-primary-50 px-2.5 py-1 text-xs font-medium text-primary-700">
                            <FormIcon size={14} />
                            {form.shortName}
                          </span>
                        ) : <span className="text-xs text-neutral-400">—</span>}
                      </td>
                      <td className="hidden px-2 lg:table-cell">
                        <div className="flex items-center gap-1">
                          <span className="font-mono text-xs text-neutral-600">
                            {showPwd ? emp.password : '••••••••'}
                          </span>
                          <button
                            onClick={() => setShowPasswords((p) => ({ ...p, [emp.id]: !p[emp.id] }))}
                            className="rounded p-1 text-neutral-400 hover:text-neutral-600"
                          >
                            {showPwd ? <EyeOff size={14} /> : <Eye size={14} />}
                          </button>
                        </div>
                      </td>
                      <td className="hidden px-2 text-xs text-neutral-500 xl:table-cell">{formatDateShort(emp.createdAt)}</td>
                      <td className="py-3 pl-2">
                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => handlePrintEmployee(emp, 'midyear')}
                            className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-neutral-500 hover:bg-secondary-50 hover:text-secondary-600"
                            title="طباعة التقييم النصفي"
                          >
                            <Printer size={14} />نصفي
                          </button>
                          <button
                            onClick={() => handlePrintEmployee(emp, 'final')}
                            className="flex items-center gap-1 rounded-lg px-2 py-1.5 text-xs text-neutral-500 hover:bg-secondary-50 hover:text-secondary-600"
                            title="طباعة التقييم النهائي"
                          >
                            <Printer size={14} />نهائي
                          </button>
                          <button
                            onClick={() => openEditForm(emp)}
                            className="rounded-lg p-1.5 text-neutral-500 hover:bg-primary-50 hover:text-primary-600"
                            title="تعديل"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            onClick={() => openResetDialog(emp)}
                            className="rounded-lg p-1.5 text-neutral-500 hover:bg-accent-50 hover:text-accent-600"
                            title="إعادة ضبط كلمة المرور"
                          >
                            <KeyRound size={16} />
                          </button>
                          <button
                            onClick={() => setDeleteTarget(emp)}
                            className="rounded-lg p-1.5 text-neutral-500 hover:bg-error-50 hover:text-error-600"
                            title="حذف"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Add/Edit modal */}
      <Modal
        open={showForm}
        onClose={() => setShowForm(false)}
        title={editingUser ? 'تعديل بيانات الموظف' : 'إضافة موظف جديد'}
        size="md"
      >
        <div className="space-y-4">
          <div>
            <label className="label-field">الاسم الكامل <span className="text-error-500">*</span></label>
            <input
              type="text"
              value={formData.fullName}
              onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
              className="input-field"
              placeholder="اسم الموظف"
            />
          </div>

          <div>
            <label className="label-field">رقم السجل المدني <span className="text-error-500">*</span></label>
            <input
              type="text"
              value={formData.civilId}
              onChange={(e) => setFormData({ ...formData, civilId: e.target.value })}
              className="input-field"
              placeholder="رقم السجل المدني"
            />
          </div>

          <div>
            <label className="label-field">المسمى الوظيفي</label>
            <input
              type="text"
              value={formData.jobTitle}
              onChange={(e) => setFormData({ ...formData, jobTitle: e.target.value })}
              className="input-field"
              placeholder="معلم، محضر مختبر، موجه طلابي..."
            />
          </div>

          <div>
            <label className="label-field">نموذج التقييم <span className="text-error-500">*</span></label>
            <select
              value={formData.formType}
              onChange={(e) => setFormData({ ...formData, formType: e.target.value as FormType })}
              className="input-field"
            >
              {Object.values(EVALUATION_FORMS).map((f) => {
                const Icon = formIconMap[f.icon];
                return (
                  <option key={f.type} value={f.type}>
                    {f.name} ({f.criteria.length} بند)
                  </option>
                );
              })}
            </select>
          </div>

          <div>
            <label className="label-field">كلمة المرور <span className="text-error-500">*</span></label>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <input
                  type={showFormPassword ? 'text' : 'password'}
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="input-field pl-10"
                  placeholder="كلمة المرور"
                />
                <button
                  type="button"
                  onClick={() => setShowFormPassword(!showFormPassword)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-600 text-xs"
                >
                  {showFormPassword ? 'إخفاء' : 'إظهار'}
                </button>
              </div>
              <button
                type="button"
                onClick={() => {
                  const pwd = generatePassword();
                  setFormData({ ...formData, password: pwd });
                  setShowFormPassword(true);
                  toast('info', `تم توليد كلمة مرور: ${pwd}`);
                }}
                className="btn-outline whitespace-nowrap"
              >
                <RefreshCw size={16} />
                توليد عشوائي
              </button>
            </div>
          </div>

          <label className="flex items-center gap-2 text-sm text-neutral-700">
            <input
              type="checkbox"
              checked={formData.mustChangePassword}
              onChange={(e) => setFormData({ ...formData, mustChangePassword: e.target.checked })}
              className="h-4 w-4 rounded border-neutral-300 text-primary-600 focus:ring-primary-500"
            />
            طلب تغيير كلمة المرور عند أول دخول
          </label>

          <div className="flex justify-start gap-2 pt-2">
            <button onClick={handleSave} disabled={saving} className="btn-primary w-full sm:w-auto">
              <Check size={18} />
              {saving ? 'جاري الحفظ...' : editingUser ? 'حفظ التعديلات' : 'إضافة الموظف'}
            </button>
            <button onClick={() => setShowForm(false)} className="btn-outline">
              <X size={18} />
              إلغاء
            </button>
          </div>
        </div>
      </Modal>

      {/* Delete confirm */}
      <ConfirmDialog
        open={!!deleteTarget}
        onClose={() => setDeleteTarget(null)}
        onConfirm={handleDelete}
        title="حذف الموظف"
        message={`هل أنت متأكد من حذف "${deleteTarget?.fullName}"؟ سيتم حذف جميع الشواهد والتقييمات المرتبطة به.`}
        confirmLabel="نعم، حذف نهائي"
        danger
      />

      {/* Reset password modal */}
      <Modal
        open={!!resetTarget}
        onClose={() => setResetTarget(null)}
        title="إعادة ضبط كلمة المرور"
        size="sm"
      >
        <div className="space-y-4">
          <p className="text-sm text-neutral-600">
            سيتم إعادة ضبط كلمة مرور <span className="font-bold">{resetTarget?.fullName}</span>. سيُطلب منه تغييرها عند الدخول.
          </p>
          <div className="flex gap-2">
            <input
              type="text"
              value={resetPasswordValue}
              onChange={(e) => setResetPasswordValue(e.target.value)}
              className="input-field font-mono"
            />
            <button
              type="button"
              onClick={() => { setResetPasswordValue(generatePassword()); }}
              className="btn-outline whitespace-nowrap"
            >
              <RefreshCw size={16} /> توليد
            </button>
          </div>
          <div className="flex justify-start gap-2">
            <button onClick={() => handleResetPassword(resetPasswordValue)} className="btn-primary">
              <Check size={18} /> تأكيد إعادة الضبط
            </button>
            <button onClick={() => setResetTarget(null)} className="btn-outline">إلغاء</button>
          </div>
        </div>
      </Modal>
    </div>
  );
}
