import { useCallback, useEffect, useMemo, useState } from 'react';
import { Star, Save, Lock, RefreshCw, Info } from 'lucide-react';
import { EVALUATION_FORMS, RATING_LABELS, getRatingLabel } from '@/forms';
import { getEvaluation, saveSelfEvaluation, logAudit } from '@/db';
import { useAuth } from '@/context/AuthContext';
import { toast } from '@/components/ui/Toast';
import { formatDate } from '@/utils';
import type { Evaluation } from '@/types';

type Period = 'midyear' | 'final';

export function EmployeeSelfEvalPage() {
  const { user } = useAuth();
  const [period, setPeriod] = useState<Period>('midyear');
  const [evaluation, setEvaluation] = useState<Evaluation | undefined>();
  const [ratings, setRatings] = useState<Record<string, number>>({});
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const form = user ? EVALUATION_FORMS[user.formType || 'teacher'] : null;
  const locked = evaluation?.status === 'approved';

  const load = useCallback(async () => {
    if (!user) return;
    setLoading(true);
    try {
      const ev = await getEvaluation(user.id, period);
      setEvaluation(ev);
      setRatings(Object.fromEntries((ev?.selfScores || []).map((s) => [s.criterionId, s.rating])));
      setNotes(ev?.selfNotes || '');
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر تحميل التقييم الذاتي');
    } finally { setLoading(false); }
  }, [user, period]);

  useEffect(() => { load(); }, [load]);

  const summary = useMemo(() => {
    if (!form) return { percent: 0, answered: 0 };
    const maxTotal = form.criteria.reduce((s, c) => s + c.weight, 0);
    const total = form.criteria.reduce((s, c) => s + (ratings[c.id] ? (ratings[c.id] / 5) * c.weight : 0), 0);
    return { percent: maxTotal ? (total / maxTotal) * 100 : 0, answered: form.criteria.filter((c) => ratings[c.id]).length };
  }, [form, ratings]);

  if (!user || !form) return null;

  const handleSave = async () => {
    if (summary.answered === 0) {
      toast('error', 'قيّم بنداً واحداً على الأقل قبل الحفظ');
      return;
    }
    setSaving(true);
    try {
      const selfScores = form.criteria.filter((c) => ratings[c.id]).map((c) => ({ criterionId: c.id, rating: ratings[c.id] }));
      await saveSelfEvaluation(user.id, period, selfScores, notes.trim());
      void logAudit(user, 'حفظ تقييم ذاتي', `${period === 'midyear' ? 'نصف سنوي' : 'نهائي'} | ${summary.answered} بند`);
      toast('success', 'تم حفظ تقييمك الذاتي');
      await load();
    } catch (error) {
      toast('error', error instanceof Error ? error.message : 'تعذر حفظ التقييم الذاتي');
    } finally { setSaving(false); }
  };

  return (
    <div className="space-y-6">
      {loading && (
        <div className="flex items-center justify-center gap-2 rounded-xl border border-primary-100 bg-primary-50 px-4 py-3 text-sm text-primary-700">
          <RefreshCw size={16} className="animate-spin" /> جاري التحميل...
        </div>
      )}

      <div className="flex items-start gap-2 rounded-xl border border-secondary-200 bg-secondary-50 px-4 py-3 text-sm text-secondary-800">
        <Info size={18} className="mt-0.5 flex-shrink-0" />
        <p>قيّم أداءك بنفسك في كل بند من 1 إلى 5. التقييم الذاتي <b>تقديري للمقارنة فقط</b>، ولا يغيّر درجة المدير، وسيظهر له بجانب تقييمه.</p>
      </div>

      <div className="card">
        <label className="label-field">فترة التقييم</label>
        <div className="flex gap-2">
          {(['midyear', 'final'] as Period[]).map((p) => (
            <button key={p} onClick={() => setPeriod(p)} className={period === p ? 'btn-primary' : 'btn-outline'}>
              {p === 'midyear' ? 'نصف سنوي' : 'نهائي'}
            </button>
          ))}
        </div>
        {locked && (
          <p className="mt-3 flex items-center gap-2 text-xs text-success-700"><Lock size={14} /> اعتمد المدير هذا التقييم، فلا يمكن تعديل التقييم الذاتي لهذه الفترة.</p>
        )}
      </div>

      <div className="space-y-4">
        {form.criteria.map((criterion, idx) => (
          <div key={criterion.id} className="card">
            <div className="mb-3 flex items-start gap-3">
              <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-lg bg-secondary-100 text-sm font-bold text-secondary-700">{idx + 1}</span>
              <div>
                <h4 className="text-sm font-bold text-neutral-800">{criterion.label}</h4>
                <span className="badge bg-primary-50 text-primary-700">الوزن: {criterion.weight}%</span>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  disabled={locked}
                  onClick={() => setRatings((prev) => ({ ...prev, [criterion.id]: rating }))}
                  className={`flex items-center gap-1 rounded-lg border px-3 py-1.5 text-xs font-bold transition-all ${locked ? 'cursor-not-allowed opacity-60 ' : ''}${
                    ratings[criterion.id] === rating
                      ? 'border-primary-500 bg-primary-50 text-primary-700 shadow-card'
                      : 'border-neutral-200 bg-white text-neutral-500 hover:border-primary-300'
                  }`}
                >
                  <Star size={14} className={ratings[criterion.id] === rating ? 'fill-primary-500 text-primary-500' : ''} />
                  {rating} — {RATING_LABELS[rating]}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="card space-y-4">
        <div>
          <label className="label-field">ملاحظاتك (اختياري)</label>
          <textarea value={notes} onChange={(e) => setNotes(e.target.value)} disabled={locked} className="input-field min-h-[80px] disabled:bg-neutral-100" placeholder="أي توضيح تريد أن يراه المدير..." />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-xl bg-neutral-50 p-4 text-center">
            <p className="text-xs text-neutral-500">نسبتك الذاتية</p>
            <p className="text-2xl font-bold text-neutral-800">{summary.percent.toFixed(1)}%</p>
          </div>
          <div className="rounded-xl bg-neutral-50 p-4 text-center">
            <p className="text-xs text-neutral-500">التقدير</p>
            <p className="text-lg font-bold text-neutral-800">{summary.answered ? getRatingLabel((summary.percent / 100) * 5) : '—'}</p>
          </div>
        </div>
        {evaluation?.selfUpdatedAt && <p className="text-center text-xs text-neutral-400">آخر حفظ: {formatDate(evaluation.selfUpdatedAt)}</p>}
        <button onClick={handleSave} disabled={saving || locked} className="btn-primary w-full sm:w-auto">
          <Save size={18} /> {saving ? 'جاري الحفظ...' : 'حفظ التقييم الذاتي'}
        </button>
      </div>
    </div>
  );
}
