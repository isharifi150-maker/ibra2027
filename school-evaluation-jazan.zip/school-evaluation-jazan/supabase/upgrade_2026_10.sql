-- Run ONCE in Supabase SQL Editor. Safe to re-run. Does not touch existing data.

-- 1) Teacher announcement + evidence deadline (shown on teacher dashboard)
alter table public.school_settings add column if not exists announcement text;
alter table public.school_settings add column if not exists evidence_deadline text;

-- Make sure a settings row exists so the announcement can be saved
insert into public.school_settings (id, school_name)
values ('default', '')
on conflict (id) do nothing;

-- 2) Audit log
create table if not exists public.audit_log (
  id uuid primary key default gen_random_uuid(),
  actor_id text,
  actor_name text,
  action text not null,
  details text,
  created_at timestamptz not null default now()
);
create index if not exists audit_log_created_idx on public.audit_log(created_at desc);
alter table public.audit_log enable row level security;
do $$ begin
  create policy "app audit access" on public.audit_log for all to anon, authenticated using (true) with check (true);
exception when duplicate_object then null; end $$;

-- 3) Evidence upload limit: 2 MB (matches the message shown to teachers)
update storage.buckets set file_size_limit = 2097152 where id = 'employee-evidence';

-- 4) Self-evaluation: teacher's own ratings, stored on the evaluation row
alter table public.evaluations add column if not exists self_scores jsonb not null default '[]'::jsonb;
alter table public.evaluations add column if not exists self_notes text not null default '';
alter table public.evaluations add column if not exists self_updated_at timestamptz;
